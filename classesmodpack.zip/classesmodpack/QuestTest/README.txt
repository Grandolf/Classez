QuestTest modpack for Minetest v0.4.10 by fessmk. All code under WTFPL, unless noted below. All images under WTFPL, unless noted below. All meshes are under WTFPL, unless noted below. Have fun with this mod, that is the only rule.
Forum String:https://forum.minetest.net/viewtopic.php?f=9&t=9844 (at the present)
---------------
Credits
---------------
TNT api:
edited from sfan5's nuke mod, and is under GPLv2

explode api:
copied form tnt mod by PilzAdam and ShadowNinja. (mod in default game) Under WTFPL

Throwing item api:
edited from PlzAdam's Throwing and Jeija's throwing mods which are under WTFPL and WTFPL, respectively (excuse the redundency)

Mob api:
PlzAdam's Mobs mod, and is under WTFPL
also, some edits based upon Blockmen's Creatures mod (WTFPL), kpgmobs (MIT)* and the Mobs mod by by PilzAdam, KrupnovPavel, Zeg9 and TenPlus1(MIT)*

basic_zombie mesh:
Blockmen's Creatures mod, under WTFPL

all overworld Zombie textures:
edited by myself from the zombie texture from Blockmen's Creatures mod, under WTFPL

Sheep, avenging_ent, grim_reaper and basic_golom mesh:
PlzAdam's Mobs mod, under WTFPL

Sheep_normal, sheep_normal_shaved, avenging_ent textures:
PlzAdam's Mobs mod, under WTFPL

Human mesh:
copied from default character.x, thus under CC BY-SA 3.0

Criminal and Villiger textures:
edited from default character.png thus under WTFPL

grim reaper texture:
edited from Plzadam's mobs mod, under WTFPL

sheep.ogg:
copied from Plzadam's mobbs mod, under WTFPL

boss_noise.ogg, criminal_laugh.ogg,  skeleton.ogg, undead_mob_hurt.ogg, and undead_mob_grunt.ogg:
copied from custom_sounds download, by Inocudom. License: CC BY-SA

code for qt_chests:
edited from Blockmen's Piramids mod, under WTFPL

code for qt_dungeons:
edited from the instabuild mod, and is licensed under CC BY-SA

awesome(diamond) armor images:
from the 3d_armor made by stu, and under 2013 Ryan Jones - CC-BY-SA
they were only reproduced because of naming issues in the 3d_armor mod.

/clearall chatcommand code:
copied from playereffects examples.lua, and is under WTFPL


*MIT:
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

NOTE:THIS IS THE MIT LICENS, NOT THE LICENS OF MOST OF QUESTEST