--basic stuff



--TNT
--This does not add the node. Register the node yourself, and have the on_hit to add the entity and remove the node.
--def info (required)
--tdef.radus
--tdef.sound (of the explosion)
--tdef.texture(.top, .bottom, .side)
--tdef.timer
--tdef.damage
--tdef.entityname (this is used to add the entity after hitting the node)
--tdef.entityshortname
--tdef.nodename (for defusing the TNT. this node is added to the hitter's inventory)

--nodedef
--
--name = the node's name
--description = the node's description
--tiles = the images
--tiles.top, tiles. side, tiles.bottom = self explanatory

--entitydef
--name = the entity's name
--tiles = same as nodedef
--radius = the ecplosion radius
--timer = how long till the explosion

-- TNT api has been made nil in minetest V. 1.4.14

function qt.register_tnt(nodedef, entitydef)
	minetest.register_node(nodedef.name, {
		description = nodedef.description,
		tiles = {nodedef.tiles.top, nodedef.tiles.bottom, nodedef.tiles.side},
		is_ground_content = false,
		groups = {crumbly=3,},
		sounds = default.node_sound_dirt_defaults(),
		on_punch = function(pos, node, puncher)
			minetest.remove_node(pos)
			local obj = minetest.add_entity(pos, entitydef.name)
			if obj then
				obj:setacceleration({ x = 0, y = -10, z = 0})
			end
		end,
		on_blast = function(pos, intensity)
			minetest.remove_node(pos)
			local obj =  minetest.add_entity(pos, entitydef.name .."_short")
			if obj then
				obj:setacceleration({ x = 0, y = -10, z = 0})
			end
		end,
		on_lightning_strike = function(pos, dist)
			minetest.remove_node(pos)
			local obj =  minetest.add_entity(pos, entitydef.name .."_short")
			if obj then
				obj:setacceleration({ x = 0, y = -10, z = 0})
			end
		end,
	})

	minetest.register_entity(entitydef.name, {
		physical = true,
		collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
		visual = "cube",
		textures = {entitydef.tiles.top, entitydef.tiles.bottom,
				entitydef.tiles.side, entitydef.tiles.side,
				entitydef.tiles.side, entitydef.tiles.side},
		timer = 0,
		health = 1,
		radius = entitydef.radius,
		nodename = nodedef.name,
		boom_timer = entitydef.timer,

		on_step = function (self, dtime)
			self.timer = self.timer + dtime
			local tntpos = self.object:getpos()
			local below = {x = tntpos.x, y = tntpos.y-1, z = tntpos.z}
			local node_below = minetest.get_node(below)
			--[[
			if node_below.name == "air" then
				self.object:setvelocity ({ x = 0, y = -10, z = 0})
			end
			--]]
			if self.timer > self.boom_timer then
				qt.explode(tntpos, self.radius)
				self.object:remove()
			end
		end,

		on_punch = function (self, hitter)
			self.object:remove()
			hitter:get_inventory():add_item("main", self.nodename)
		end,
	})


	--tnt entity for tnt activated by nearby explosion
	minetest.register_entity(entitydef.name .."_short", {
		physical = true,
		collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
		visual = "cube",
		textures = {entitydef.tiles.top, entitydef.tiles.bottom,
				entitydef.tiles.side, entitydef.tiles.side,
				entitydef.tiles.side, entitydef.tiles.side},
		timer = 0,
		health = 1,
		radius = entitydef.radius,
		nodename = nodedef.name,
		boom_timer = entitydef.timer/4,

		on_step = function (self, dtime)
			self.timer = self.timer + dtime
			local tntpos = self.object:getpos()
			local below = {x = tntpos.x, y = tntpos.y-1, z = tntpos.z}
			local node_below = minetest.get_node(below)
			--[[
			if node_below.name == "air" then
				self.object:setvelocity ({ x = 0, y = -10, z = 0})
			end
			--]]
			if self.timer > self.boom_timer then
				qt.explode(tntpos,self.radius)
				self.object:remove()
			end
		end,

		on_punch= function (self, hitter)
			self.object:remove()
			hitter:get_inventory():add_item("main", self.nodename)
		end,
	})

end

--some basic shooting functions (these can be used as the sdef.entity_on_hit_entity_function (obj, pos), sdef.entity_on_hit_node_function (nodename, pos, lastpos), and
--sdef,entity_max_fange_function. if those are left nil, these are used)
--note: the register_shooter code automatically removes the shot entity for you

function qt.entity_hit_entity_basic (damage, self, object)
	object:punch(self.object, 1.0, {
						full_punch_interval=1.0,
						damage_groups={fleshy=damage},
					}, nil)
end

function qt.entity_hit_node_basic (last_pos, drop)
	minetest.add_item(last_pos, drop)
end

function qt.entity_max_range_basic ()
end

--register_arrow
--def required info
--
--sdef.drop
--sdef.entity_name
--sdef.entity_image
--sdef.entity_min_range
--sdef.entity_max_range
--sdef.damage (how much damage a entity receives if no special function)
--sdef.on_hit_entity (self, obj)  leave blank to punch entity
--sdef.on_hit_node (self, node) leave blank to drop ammo, if any   ---all three of these functions automatically remove arrow
--sdef.on_leave_range (self) leave blank for no action
--sdef.visual

function qt.register_arrow(sdef)

	if sdef.drop == nil and sdef.ammo_name ~= nil then
		sdef.drop = sdef.ammo_name
	end

	minetest.register_entity(sdef.entity_name, {
		physical = false,
		timer=0,
		visual = sdef.visual,
		visual_size = {x=0.1, y=0.1},
		textures = sdef.entity_image,
		lastpos={},
		collisionbox = {0,0,0,0,0,0},
		hit_node = sdef.on_hit_node,
		hit_entity = sdef.on_hit_entity,
		leave_range = sdef.on_leave_range,
		drop = sdef.drop,
		damage = sdef.damage,
		max_range = sdef.entity_max_range,

		on_step = function(self, dtime)
			self.timer=self.timer+dtime
			local pos = self.object:getpos()
			local node = minetest.env:get_node(pos)
			--hit an entity
			if self.timer>sdef.entity_min_range then
				local objs = minetest.env:get_objects_inside_radius({x=pos.x,y=pos.y,z=pos.z}, 2)
				for k, obj in pairs(objs) do
					if obj:get_luaentity() ~= nil then
						if obj:get_luaentity().name ~= sdef.entity_name and obj:get_luaentity().name ~= "__builtin:item" then
							if self.hit_entity ~= nil then
								self.hit_entity (self, obj)
							else
								qt.entity_hit_entity_basic (self.damage, self, obj)
							end
							self.object:remove()
						end
					end
				end
			end
			--hit a node
			if self.lastpos.x~=nil then
				if node.name ~= "air" then
					if self.hit_node ~= nil then
						self.hit_node (self, node)
					elseif sdef.drop ~= nil then
						qt.entity_hit_node_basic (self.lastpos, self.drop)
					end
					self.object:remove()
				end
			end
			--go out of bounds
			if sdef.entity_max_range ~= nil then
				if self.timer> sdef.entity_max_range then
					if self.leave_range ~= nil then
						self.leave_range (self)
					else
						qt.entity_max_range_basic ()
					end
					self.object:remove()
				end
			end
			self.lastpos={x=pos.x, y=pos.y, z=pos.z}
		end,
	})

end


function qt.add_and_shoot (player, entityname)
	local playerpos = player:getpos()
	local obj = minetest.add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, entityname)
	qt.shoot_entity(player, obj)
end

function qt.shoot_entity (player, entityref)
	local playerpos = player:getpos()
	local dir = player:get_look_dir()
	entityref:setvelocity({x=dir.x*19, y=dir.y*19, z=dir.z*19})
	entityref:setacceleration({x=dir.x*-3, y=-10, z=dir.z*-3})
	entityref:setyaw(player:get_look_yaw()+math.pi)
end

function qt.add_and_shoot_spread (player, entityname)
	local playerpos = player:getpos()
	local obj = minetest.add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, entityname)
	qt.shoot_entity_spread(player, obj)
end

function qt.shoot_entity_spread (player, entityref)
	local playerpos = player:getpos()
	local dir = player:get_look_dir()
	local r1 = math.random(-5, 5)
	local r2 = math.random(-5, 5)
	local r3 = math.random(-5, 5)
	r1 = r1/5
	r2 = r2/5
	r3 = r3/5
	entityref:setvelocity({x=dir.x*19+r1, y=dir.y*19+r2, z=dir.z*19+r3})
	entityref:setacceleration({x=dir.x*-3, y=-10, z=dir.z*-3})
	entityref:setyaw(player:get_look_yaw()+math.pi)
end

--[[
for x=-IRON_TNT_RANGE,IRON_TNT_RANGE do
        for y=-IRON_TNT_RANGE,IRON_TNT_RANGE do
        for z=-IRON_TNT_RANGE,IRON_TNT_RANGE do
            if x*x+y*y+z*z <= IRON_TNT_RANGE * IRON_TNT_RANGE + IRON_TNT_RANGE then
                local np={x=pos.x+x,y=pos.y+y,z=pos.z+z}
                local n = minetest.get_node(np)
                if n.name ~= "air" then
                    minetest.remove_node(np)
                end
                activate_if_tnt(n.name, np, pos, IRON_TNT_RANGE)
            end
        end
        end
        end
--]]

-- returns table of
--table{pos={x, y, z}, noderef}

function qt.get_nodes_in_radius(pos, radius)
	if pos ~= nil and radius ~= nil then
		local ntable = {}
		local counter = 1
		for x = -radius, radius do
		for y = -radius, radius do
		for z = -radius, radius do
			if x*x+y*y+z*z <= radius*radius+radius then
				local npos = {x=pos.x+x,y=pos.y+y,z=pos.z+z}
				local nref = minetest.get_node(npos)
				ntable[counter]={}
				ntable[counter].pos = npos
				ntable[counter].noderef = nref
				counter = counter+1
			end
		end
		end
		end
		return ntable
	else
		return nil
	end
end

--for _, nodedat in ipairs(nodetable) do
function qt.get_nodes_on_radius(pos, radius)
	if pos ~= nil and radius ~= nil then
		local ntable = {}
		local counter = 1
		local t_all = qt.get_nodes_in_radius(pos, radius)
		local t_inside = qt.get_nodes_in_radius(pos, radius-1)
		for _, dat_all in ipairs(t_all) do
			local is_on_outside = true
			for _, dat_inside in ipairs(t_inside) do
				if dat_inside.pos.x == dat_all.pos.x and dat_inside.pos.y == dat_all.pos.y and dat_inside.pos.z == dat_all.pos.z then
					is_on_outside = false
				end
			end
			if is_on_outside == true then
				ntable[counter]={}
				ntable[counter].pos = dat_all.pos
				ntable[counter].noderef = dat_all.noderef
				counter = counter+1
			end
		end
		return ntable
	else
		return nil
	end
end

--[[
this function does not get nodes in a hollow shpere. It is terrably inaccurate


function qt.get_nodes_on_radius_alt(pos, radius)
	if pos ~= nil and radius ~= nil then
		local ntable = {}
		local counter = 1
		for x = -radius, radius do
		for y = -radius, radius do
		for z = -radius, radius do
			if x*x+y*y+z*z <= radius*radius+radius and x*x+y*y+z*z > radius*radius+radius-1 then
				local npos = {x=pos.x+x,y=pos.y+y,z=pos.z+z}
				local nref = minetest.get_node(npos)
				ntable[counter]={}
				ntable[counter].pos = npos
				ntable[counter].noderef = nref
				counter = counter+1
			end
		end
		end
		end
		return ntable
	else
		return nil
	end
end

--]]

--minetest.registered_items

--[[
callbacks

on_walk(pos, playername, damagetimer)
on_walk_in(pos, playername, damagetimer)
no return

on_carry(itemstack, playername, damagetimer)
return itemstack

on_wield(itemstack, playername, damagetimer)
return itemstack
--]]
--[[
qt.nodetimers = {}
qt.nodetimers.damage_tick = 1
qt.nodetimers.damage_tick_timer = 0

qt.nodetimers.general_action = 0.5
qt.nodetimers.general_action_timer = 0
--]]

local damage = 0

minetest.register_globalstep(function(dtime)
	--qt.nodetimers.damage_tick_timer = qt.nodetimers.damage_tick_timer + dtime
	--qt.nodetimers.general_action_timer = qt.nodetimers.general_action_timer + dtime
	damage = damage + dtime
	--minetest.debug(damage)
	for _, player in ipairs(minetest.get_connected_players()) do
		local pos = player:getpos()
		local inv = player:get_inventory()
		local wield = player:get_wielded_item()

		pos.y = pos.y-0.5
		local node = minetest.get_node(pos)
		local nodedat = minetest.registered_nodes[node.name]
		if nodedat ~= nil and nodedat.on_walk ~= nil then
			nodedat.on_walk(pos, player:get_player_name(), damage)
		end

		local nodeb = minetest.get_node({x=pos.x, y=pos.y+1, z=pos.z})
		local nodedatb = minetest.registered_nodes[nodeb.name]
		if nodedatb ~= nil and nodedatb.on_walk_in ~= nil then
			nodedatb.on_walk_in({x=pos.x, y=pos.y+1, z=pos.z}, player:get_player_name(), damage)
		end

		--if qt.nodetimers.general_action_timer == qt.nodetimers.general_action then

			local invlist = inv:get_list("main")
			local invlist_n = {}
			for ref, itemstack in ipairs(invlist) do
				--local itemname = itemstack:get_name()
				local itemdat = minetest.registered_items[itemstack:get_name()]
				if itemdat ~= nil and itemdat.on_carry ~= nil then
					local itemstack_n = itemdat.on_carry(itemstack, player:get_player_name(), damage)
					if itemstack_n ~= nil then
						invlist_n[ref]=itemstack_n
					else
						invlist_n[ref]=itemstack
					end
				else
					invlist_n[ref]=itemstack
				end
			end
			inv:set_list("main", invlist_n)

			local wielddat = minetest.registered_items[wield:get_name()]
			if wielddat ~= nil and wielddat.on_wield ~= nil then
				local wield_n = wielddat.on_wield(wield, player:get_player_name(), damage)
				if wield_n ~= nil then
					player:set_wielded_item(wield_n)
				end
			end
		--qt.nodetimers.general_action_timer = 0
		--end
	end
	--[[
	if qt.nodetimers.damage_tick_timer == qt.nodetimers.damage_tick then
		qt.nodetimers.damage_tick_timer = 0
	end

	if qt.nodetimers.general_action_timer == qt.nodetimers.general_action then
		qt.nodetimers.general_action_timer = 0
	end
	--]]

	if damage >= 1 then
		damage = 0
	end
end)


--[[
minetest.register_node(":qt:aaatestnode", {
	description = "TestNode",
	tiles = {"corilium_block.png"},
	is_ground_content = false,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	on_walk = function(pos, player)
		minetest.set_node(pos, {name = "default:diamondblock"})
		minetest.debug("node walked on")
	end,
	on_walk_in = function(pos, player)
		minetest.set_node(pos, {name = "default:stone"})
		minetest.debug("node walked in")
	end,
	--on_carry = function(itmestack, player)
		--minetest.debug("item carried")
	--end,
	on_wield = function(itmemstack, player)
		minetest.debug("item wielded")
	end,
	on_use = function(itemstack, player, pointed_thing)
		qt.strike_lightning(pointed_thing.above)
	end,
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "default:goldblock"})
	end,
})
--]]

--[[
callbacks:
on_lightning_strike(pos, dist)


--]]
qt.makeplus = function(num)
	if num < 0 then
		num = -num
	elseif num >= 0 then
		num = num
	end

	return num
end

qt.find_dist = function(pos_a, pos_b)
	local dist = 0
	local x = qt.makeplus(qt.makeplus(pos_a.x) - qt.makeplus(pos_b.x))
	local y = qt.makeplus(qt.makeplus(pos_a.y) - qt.makeplus(pos_b.y))
	local z = qt.makeplus(qt.makeplus(pos_a.z) - qt.makeplus(pos_b.z))

	dist = math.sqrt(x*x+y*y+z*z)

	return dist
end



function qt.strike_lightning(pos)
	local lobj = minetest.add_entity({x=pos.x, y=pos.y+1, z=pos.z}, "qt:lightning_entity")

	minetest.after(0.3, function(lobj, pos)
		lobj:setyaw(lobj:getyaw()+90)

		local nodes = qt.get_nodes_in_radius(pos, 2)
		for _, node in ipairs(nodes) do
			local nodedat = minetest.registered_nodes[node.noderef.name]
			if nodedat ~= nil and nodedat.on_lightning_strike ~= nil then
				local dist = qt.find_dist(pos, node.pos)
				nodedat.on_lightning_strike(node.pos, dist)
			elseif nodedat ~= nil and nodedat.groups.flammable ~= nil then
				minetest.set_node(node.pos, {name = "fire:basic_flame"})
			end
		end

	end, lobj, pos)

	minetest.after(0.6, function(lobj)
		lobj:remove()
	end, lobj)

end

minetest.register_craftitem("qt:liquidsuit", {
	description = "Liquid Protectiion Suit",
	inventory_image = "liquid_suit.png",
	stack_max = 1,
})

function qt.player_has_suit(player)
	local inv = player:get_inventory()
	local invlist = inv:get_list("main")
	local invlist_n = {}
	for ref, itemstack in ipairs(invlist) do
		local itemname = itemstack:get_name()
		if itemname == "qt:liquidsuit" then
			return true
		end
	end
	return false
end


minetest.register_entity(":qt:lightning_entity", {
	physical = false,
	collisionbox = {0,0,0,0,0,0},
	visual = "mesh",
	textures = {"lightning.png"},
	mesh = "lightning.x",
	visual_size = {x=5,  y=15},
	on_step = function(self, dtime)

	end,
})



minetest.register_node(":default:ice", {
	description = "Ice",
	tiles = {"default_ice.png"},
	is_ground_content = false,
	paramtype = "light",
	groups = {cracky=3},
	sounds = default.node_sound_glass_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "default:water_source"})
	end,
})
