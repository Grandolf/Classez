--[[
minetest.register_tool(sdef.shootername, {
			description = sdef.shooter_def,
			inventory_image = sdef.shooter_image,
			on_use = function (itemstack, user, pointed_thing)
				if sdef.take_ammo == true then
					if not minetest.setting_getbool("creative_mode") then
						if user:get_inventory():remove_item("main", sdef.ammo_name) ~= "" then
							itemstack:add_wear(65535/sdef.tool_wear)
							qt.shoot_entity (user, sdef.entity_name)
							if sdef.shoot_sound ~= nil then
								minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
							end
						end
					else
						qt.shoot_entity (user, sdef.entity_name)
						if sdef.shoot_sound ~= nil then
							minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
						end
					end
				else
					 qt.shoot_entity (user, sdef.entity_name)
					 if sdef.shoot_sound ~= nil then
						minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
					end
				end
				return itemstack
			end,
		})

	else

		minetest.register_craftitem(sdef.shootername, {
			description = sdef.shooter_def,
			inventory_image = sdef.shooter_image,
			on_use = function (itemstack, user, pointed_thing)
				if sdef.take_ammo == true then
					if not minetest.setting_getbool("creative_mode") then
						if user:get_inventory():remove_item("main", sdef.ammo_name) ~= "" then
							qt.shoot_entity (user, sdef.entity_name)
							if sdef.shoot_sound ~= nil then
								minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
							end
						end
					else
						qt.shoot_entity (user, sdef.entity_name)
						if sdef.shoot_sound ~= nil then
							minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
						end
					end
				else
					 qt.shoot_entity (user, sdef.entity_name)
					 if sdef.shoot_sound ~= nil then
						minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
					end
				end
				return itemstack
			end,
		})
	end
--]]

--sdef.shootername
--sdef.is_shooter_tool (boolian val)
--sdef.tool_wear
--sdef.shooter_image
--sdef.shooter_def
--sdef.take_ammo (boolian value)
--sdef.ammo_name (seprately registered item, taken when shot)
--sdef.shoot_sound
--sdef.entity_name
--sdef.entity_image
--sdef.entity_weight
--sdef.entity_min_range
--sdef.damage (how much damage a entity receives of no special function)
--sdef.add_block
--sdef.block_to_add
--sdef.explode
--sdef.explode_radius
--sdef.remove_block
--sdef.explode_sound
--sdef.destory_terrain

minetest.register_node("qt:arrow_node", {
	tiles = {
		"arrow_top.png",
		"arrow_bottom.png",
		"arrow_back.png",
		"arrow_front.png",
		"arrow_side.png",
		"arrow_side_2.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.0625, -0.0625, 0.375, 0.0625, 0.0625}, -- NodeBox2
			{-0.375, -0.125, -0.0625, -0.25, 0.125, 0.0625}, -- NodeBox3
			{-0.375, -0.0625, -0.125, -0.25, 0.0625, 0.125}, -- NodeBox6
			{0.1875, 0.0625, 0, 0.5, 0.1875, 0.0625}, -- NodeBox7
			{0.1875, -0.1875, 0.0625, 0.5, -0.0625, 0.125}, -- NodeBox8
			{0.1875, -0.125, -0.1875, 0.5, -0.0625, -0.0625}, -- NodeBox9
		}
	}
})

--sdef.drop
--sdef.entity_name
--sdef.entity_image
--sdef.entity_min_range
--sdef.entity_max_range
--sdef.damage (how much damage a entity receives if no special function)
--sdef.on_hit_entity (self, obj)  leave blank to punch entity
--sdef.on_hit_node (self, node) leave blank to drop ammo, if any   ---all three of these functions automatically remove arrow
--sdef.on_leave_range (self) leave blank for no action
--sdef.visual


--[[
		bow/gun function

	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:name") then
				user:get_inventory():remove_item("main", "qt:name")
				qt.add_and_shoot (user, "qt:name")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:name")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,


	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack.take_item(1)
			qt.add_and_shoot (user, "qt:name")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:name")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
--]]



qt.register_arrow({
	drop = "qt:throwstick",
	entity_name = "qt:throwstick_entity",
	entity_image = {"default_stick.png"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 1,
	visual = "sprite",
})

minetest.register_craftitem("qt:throwstick", {
	description = "Throwing Stick",
	inventory_image = "default_stick.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:throwstick_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:throwstick_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})




minetest.register_craftitem("qt:pebble", {
	description = "Pebble",
	inventory_image = "pebble.png",
})

minetest.register_craftitem("qt:arrow", {
	description = "Arrow (basic bow ammo)",
	inventory_image = "arrow.png",
})

minetest.register_craft({
	output = 'qt:pebble 9',
	recipe = {
		{'default:gravel'},
	}
})

minetest.register_craft({
	output = 'qt:arrow',
	recipe = {
		{'group:stick', 'group:stick', 'qt:pebble'},
	}
})

qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:low_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 2,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_low", {
	description = "Low Power Bow",
	inventory_image = "basic_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:low_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:low_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})


minetest.register_craft({
	output = 'qt:bow_low',
	recipe = {
		{'', 'group:stick', 'farming:string'},
		{'group:stick', '', 'farming:string'},
		{'', 'group:stick', 'farming:string'},
	}
})



qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:med_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 4,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_med", {
	description = "Medium Power Bow",
	inventory_image = "basic_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:med_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:med_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_med',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', '', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})

qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:high_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 6,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_high", {
	description = "High Power Bow",
	inventory_image = "high_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:high_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:high_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_high',
	recipe = {
		{'group:wood', 'default:steel_ingot', 'farming:string'},
		{'default:steel_ingot', '', 'farming:string'},
		{'group:wood', 'default:steel_ingot', 'farming:string'},
	}
})

qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:obsidian_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 9,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_obsidian", {
	description = "Obsidian Bow",
	inventory_image = "obsidian_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:obsidian_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:obsidian_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_obsidian',
	recipe = {
		{'', 'default:obsidian_shard', 'farming:string'},
		{'default:obsidian_shard', '', 'farming:string'},
		{'', 'default:obsidian_shard', 'farming:string'},
	}
})

local fire = true
if fire == true then
qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:fire_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 10,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "fire:basic_flame"})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_fire", {
	description = "Fire Bow",
	inventory_image = "fire_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:fire_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:fire_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_fire',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'qt:farmite_powder', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end



local lava = true
if lava == true then
qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:lava_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 12,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:lava_source"})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_lava", {
	description = "Lava Bow",
	inventory_image = "lava_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:lava_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:lava_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_lava',
	recipe = {
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:bow_fire', 'qt:farmite_powder'},
		{'qt:farmite_powder', 'qt:farmite_powder', 'qt:farmite_powder'},
	}
})
end

local water = true
if water == true then
qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:water_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 8,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:water_source"})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_water", {
	description = "Water Bow",
	inventory_image = "water_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:water_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:water_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_water',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'qt:olmite_powder', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end

local ice = true
if ice == true then
qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:ice_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 10,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:ice"})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_ice", {
	description = "Ice Bow",
	inventory_image = "ice_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:ice_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:ice_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_ice',
	recipe = {
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:bow_water', 'qt:olmite_powder'},
		{'qt:olmite_powder', 'qt:olmite_powder', 'qt:olmite_powder'},
	}
})
end

local sand = true
if sand == true then
qt.register_arrow({
	drop = "qt:arrow",
	entity_name = "qt:sand_arrow_entity",
	entity_image = {"qt:arrow_node"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 6,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:sand"})
		nodeupdate({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:bow_sand", {
	description = "Sand Bow",
	inventory_image = "sand_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				qt.add_and_shoot (user, "qt:sand_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:sand_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:bow_sand',
	recipe = {
		{'', 'group:wood', 'farming:string'},
		{'group:wood', 'default:sand', 'farming:string'},
		{'', 'group:wood', 'farming:string'},
	}
})
end

qt.register_arrow({
	drop = "qt:copper_throwing_star",
	entity_name = "qt:copper_throwing_star_entity",
	entity_image = {"copper_throwing_star.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 4,
	visual = "sprite",
})

minetest.register_craftitem("qt:copper_throwing_star", {
	description = "Copper Throwing Star",
	inventory_image = "copper_throwing_star.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:copper_throwing_star_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:copper_throwing_star_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:copper_throwing_star 11',
	recipe = {
		{'', 'default:copper_ingot', ''},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'', 'default:copper_ingot', ''},
	}
})

qt.register_arrow({
	drop = "qt:copper_throwing_star_poisoned",
	entity_name = "qt:copper_throwing_star_poisoned_entity",
	entity_image = {"copper_throwing_star_poisoned.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 30,
	visual = "sprite",
})

minetest.register_craftitem("qt:copper_throwing_star_poisoned", {
	description = "Poisoned Copper Throwing Star",
	inventory_image = "copper_throwing_star_poisoned.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:copper_throwing_star_poisoned_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:copper_throwing_star_poisoned_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:copper_throwing_star_poisoned 11',
	recipe = {
		{'qt:poison_droplet', 'default:copper_ingot', 'qt:poison_droplet'},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'qt:poison_droplet', 'default:copper_ingot', 'qt:poison_droplet'},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:copper_throwing_star_poisoned',
	recipe = {'qt:copper_throwing_star', 'qt:poison_droplet'},
})

qt.register_arrow({
	drop = "qt:gernade",
	entity_name = "qt:gernade_entity",
	entity_image = {"gernade.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	on_hit_entity = function(self, obj)
		--qt.explode(self.object:getpos(), 4)
		tnt.boom(self.object:getpos(), {
			radius = 4,
			ignore_protection = true,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 2,
		})
		obj:punch(self.object, 1.0, {
						full_punch_interval=1.0,
						damage_groups={fleshy=20},
					}, nil)
	end,
	on_hit_node = function(self, node)
		tnt.boom(self.lastpos, {
			radius = 4,
			ignore_protection = true,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 2,
		})
	end,
	visual = "sprite",
})

minetest.register_craftitem("qt:gernade", {
	description = "Gernade",
	inventory_image = "gernade.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:gernade_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:gernade_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:gernade 9',
	recipe = {
		{'', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', 'tnt:tnt', 'default:steel_ingot'},
		{'', 'default:steel_ingot', ''},
	}
})

qt.register_arrow({
	drop = "default:diamondblock",
	entity_name = "qt:diamond_gun_entity",
	entity_image = {"default:diamondblock"},
	entity_weight = 8,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 50,
	on_hit_node = function (self, node)
		minetest.set_node({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z}, {name = "default:diamondblock"})
		nodeupdate({x = self.lastpos.x, y = self.lastpos.y, z = self.lastpos.z})
	end,
	visual = "wielditem",
})

minetest.register_tool(":qt:gun_diamond", {
	description = "Diamond Gun",
	inventory_image = "diamond_gun.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "default:diamondblock") then
				user:get_inventory():remove_item("main", "default:diamondblock")
				qt.add_and_shoot (user, "qt:diamond_gun_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:diamond_gun_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:gun_diamond',
	recipe = {
		{'default:diamondblock', 'default:diamondblock', 'default:diamond'},
		{'default:steel_ingot', 'default:diamond', ''},
		{'default:steel_ingot', 'default:wood', ''},
	}
})



minetest.register_node("qt:ruby_laser_shot_node", {
	tiles = {
		"ruby_laser_shot.png"
	},
	drawtype = "nodebox",
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.0625, -0.0625, 10.625, 0.0625, 0.0625}, -- NodeBox1
		}
	}
})

minetest.register_craftitem("qt:ruby_laser_charge", {
	description = "Ruby Laser Charge",
	inventory_image = "ruby_laser_charge.png",
})


qt.register_arrow({
	drop = "qt:ruby_laser_charge",
	entity_name = "qt:ruby_laser_gun_entity",
	entity_image = {"qt:ruby_laser_shot_node"},
	entity_weight = 0,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 25,
	visual = "wielditem",
	on_hit_node = function(self, node)
	--nil function to prevent item from being dropped
	end
})

minetest.register_tool(":qt:ruby_laser_gun", {
	description = "Ruby Laser Gun",
	inventory_image = "ruby_laser_gun.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:ruby_laser_charge") then
				user:get_inventory():remove_item("main", "qt:ruby_laser_charge")
				qt.add_and_shoot (user, "qt:ruby_laser_gun_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:ruby_laser_gun_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craft({
	output = 'qt:ruby_laser_gun',
	recipe = {
		{'default:gold_ingot', 'qt:block_gem_red', 'qt:gem_red'},
		{'default:steel_ingot', 'default:gold_ingot', ''},
		{'default:steel_ingot', '', ''},
	}
})

minetest.register_craft({
	output = 'qt:ruby_laser_charge 11',
	recipe = {
		{'default:gold_ingot'},
		{'qt:gem_red'},
		{'default:gold_ingot'},
	}
})
--[[

function add_and_shoot_shotgun (player, entityname)
	local playerpos = player:getpos()
	local obj = minetest.add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, entityname)
	shoot_entity_shotgun(player, obj)
end

function shoot_entity_shotgun (player, entityref)
	local playerpos = player:getpos()
	local dir = player:get_look_dir()
	local r1 = math.random(-5, 5)
	local r2 = math.random(-5, 5)
	local r3 = math.random(-5, 5)
	r1 = r1/5
	r2 = r2/5
	r3 = r3/5
	entityref:setvelocity({x=dir.x*19+r1, y=dir.y*19+r2, z=dir.z*19+r3})
	entityref:setacceleration({x=dir.x*-3, y=-10, z=dir.z*-3})
	entityref:setyaw(player:get_look_yaw()+math.pi)
end


minetest.register_tool(":qt:bow_shotgun", {
	description = "Ecperimental Shotgun Bow",
	inventory_image = "high_bow.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:arrow") then
				user:get_inventory():remove_item("main", "qt:arrow")
				add_and_shoot_shotgun (user, "qt:high_arrow_entity")
				add_and_shoot_shotgun (user, "qt:high_arrow_entity")
				add_and_shoot_shotgun (user, "qt:high_arrow_entity")
				add_and_shoot_shotgun (user, "qt:high_arrow_entity")
				add_and_shoot_shotgun (user, "qt:high_arrow_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			add_and_shoot_shotgun (user, "qt:high_arrow_entity")
			add_and_shoot_shotgun (user, "qt:high_arrow_entity")
			add_and_shoot_shotgun (user, "qt:high_arrow_entity")
			add_and_shoot_shotgun (user, "qt:high_arrow_entity")
			add_and_shoot_shotgun (user, "qt:high_arrow_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})
--]]

qt.register_arrow({
	drop = "qt:plasma_charge",
	entity_name = "qt:plasma_gun_entity",
	entity_image = {"plasma_shot.png"},
	entity_weight = 0,
	entity_min_range = 0.2,
	entity_max_range = 50,
	damage = 75,
	visual = "sprite",
	on_hit_node = function(self, drop)
		local node = minetest.get_node(self.object:getpos())
		local nodedat = minetest.registered_nodes[node.name]
		if nodedat.diggable ~= false then
			minetest.remove_node(self.object:getpos())
		end
	end
})

minetest.register_craftitem("qt:plasma_charge", {
	description = "Plasma Charge",
	inventory_image = "plasma_charge.png",
})

minetest.register_tool(":qt:plasma_gun", {
	description = "Experimential Plasma Gun",
	inventory_image = "plasma_gun.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:plasma_charge") then
				user:get_inventory():remove_item("main", "qt:plasma_charge")
				qt.add_and_shoot (user, "qt:plasma_gun_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot (user, "qt:plasma_gun_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})

minetest.register_craftitem("qt:plasma_charge_shotgun", {
	description = "Plasma Charges for Shotgun",
	inventory_image = "plasma_charge_shotgun.png",
})

minetest.register_craft({
	output = 'qt:plasma_charge_shotgun',
	recipe = {
		{'', 'qt:plasma_charge', ''},
		{'qt:plasma_charge', 'qt:plasma_charge', "qt:plasma_charge"},
		{'', 'qt:plasma_charge', ""},
	}
})

minetest.register_tool(":qt:plasma_shotgun", {
	description = "Experimential Plasma Shotgun",
	inventory_image = "plasma_gun.png",
		on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			if user:get_inventory():contains_item("main", "qt:plasma_charge_shotgun") then
				user:get_inventory():remove_item("main", "qt:plasma_charge_shotgun")
				qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
				qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
				qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
				qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
				qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
				--minetest.sound_play("name", {pos=playerpos})
			end
		else
			qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
			qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
			qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
			qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
			qt.add_and_shoot_spread (user, "qt:plasma_gun_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	end,
})


qt.register_arrow({
	drop = "qt:gernade_cobalt",
	entity_name = "qt:gernade_cobalt_entity",
	entity_image = {"gernade_cobalt.png"},
	entity_weight = 10,
	entity_min_range = 0.2,
	entity_max_range = 100,
	on_hit_entity = function(self, obj)
		--qt.explode(self.object:getpos(), 4)
		tnt.boom(self.object:getpos(), {
			radius = 8,
			ignore_protection = true,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 2,
		})
		obj:punch(self.object, 1.0, {
						full_punch_interval=1.0,
						damage_groups={fleshy=60},
					}, nil)
	end,
	on_hit_node = function(self, node)
		tnt.boom(self.lastpos, {
			radius = 8,
			ignore_protection = true,
			ignore_on_blast = false,
			disable_drops = false,
			damage_radius = 2,
		})
	end,
	visual = "sprite",
})

minetest.register_craftitem("qt:gernade_cobalt", {
	description = "Cobalt Gernade",
	inventory_image = "gernade_cobalt.png",
	on_use = function (itemstack, user, pointed_thing)
		if not minetest.setting_getbool("creative_mode") then
			itemstack:take_item(1)
			qt.add_and_shoot (user, "qt:gernade_cobalt_entity")
			--minetest.sound_play("name", {pos=playerpos})
		else
			qt.add_and_shoot (user, "qt:gernade_cobalt_entity")
			--minetest.sound_play("name", {pos=playerpos})
		end
	return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:gernade_cobalt',
	recipe = {
		{'', 'qt:cobalt_ingot', ''},
		{'qt:cobalt_ingot', 'qt:gernade', 'qt:cobalt_ingot'},
		{'', 'qt:cobalt_ingot', ''},
	}
})

qt.register_arrow({
	drop = "",
	entity_name = "qt:machiene_bullet",
	entity_image = {"bullet.png"},
	entity_weight = 0.1,
	entity_min_range = 0.2,
	entity_max_range = 100,
	damage = 10,
	visual = "sprite",
})

minetest.register_tool(":qt:machiene_gun", {
	description = "Experimential Machiene Gun",
	inventory_image = "machiene_gun.png",
	on_wield = function(itmemstack, playername)
		local player = minetest.get_player_by_name(playername)
		local pcontrol = player:get_player_control()
		if pcontrol.LMB == true then
		if not minetest.setting_getbool("creative_mode") then
			if itemstack:get_wear() > 35 then
				qt.add_and_shoot (player, "qt:machiene_bullet")
				--minetest.sound_play("name", {pos=playerpos})
				itemstack:set_wear(itemstack.get_wear()-100)
			end
		else
			qt.add_and_shoot (player, "qt:machiene_bullet")
			--minetest.sound_play("name", {pos=playerpos})
		end
		return itemstack
		end
	end,
	on_use = function (itemstack, user, pointed_thing)
	end,
})
