minetest.register_node(":qt:dimentional_seperator_203948", {
	description = "Dimentional Seperator - If this is in your inventory, then deleate it!",
	tiles = {"dimentional_seperator.png"},
	groups = {
		dimentional_seperator = 1,
		not_in_creative_inventory = 1
	},
	sounds = nil,
	pointable = false,
	buildable_to = false,
	diggable = false,
	damage_per_second = 100,
	on_blast = function(pos, intensity)
		--this is blank, so it will not be destroyed
	end,
})

minetest.register_node(":qt:dimentional_hider_043967097", {
	description = "Dimentional Seperator - If this is in your inventory, then deleate it!",
	tiles = {"transperent.png"},
	groups = {
		dimentional_seperator = 1,
		not_in_creative_inventory = 1
	},
	sounds = nil,
	pointable = false,
	buildable_to = false,
	diggable = false,
	damage_per_second = 100,
	on_blast = function(pos, intensity)
		--this is blank, so it will not be destroyed
	end,
})
--

minetest.register_node(":qt:nether_stone", {
	description = "Nether Stone",
	tiles = {"nether_stone.png"},
	is_ground_content = true,
	groups = {cracky=3, stone=1, nether=1},
	sounds = default.node_sound_stone_defaults(),
	light_source = 7,
})

stairs.register_stair_and_slab("nether_stone", "qt:nether_stone",
		{cracky = 3},
		{"nether_stone.png"},
		"Nether Stone Stair",
		"Nether Stone Slab",
		default.node_sound_stone_defaults())

minetest.register_craft({
	type = "fuel",
	recipe = "qt:nether_stone",
	burntime = 555,
})

minetest.register_node(":qt:nether_sand", {
	description = "Nether Sand",
	tiles = {"nether_sand.png"},
	is_ground_content = true,
	groups = {crumbly=3, falling_node=1, sand=1, nether=1},
	sounds = default.node_sound_sand_defaults(),
	light_source = 5,
	drop = {
		max_items = 1,
		items = {
			{
				items = {'qt:fireflower_seeds'},
				rarity = 20,
			},
			{
				items = {'qt:nether_sand'},
			}
		}
	},
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:nether_sand",
	burntime = 370,
})

local growtime = 45

minetest.register_craftitem(":qt:fireflower_seeds", {
	description = "Fireflower Seeds",
	inventory_image = "fireflower_seeds.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.under ~= nil and minetest.get_node(pointed_thing.under).name == "qt:nether_sand" then
			minetest.set_node(pointed_thing.above, {name="qt:fireflower_plant_1"})
			itemstack:take_item(1)
			local pos = pointed_thing.above
			minetest.after(growtime, function(pos)
				minetest.env:set_node(pos, {name="qt:fireflower_plant_2"})
			end, pos)
			minetest.after(growtime*2, function(pos)
				minetest.env:set_node(pos, {name="qt:fireflower_plant_3"})
			end, pos)
			return itemstack
		end
	end
})

minetest.register_craftitem(":qt:fireflower", {
	description = "Fireflower",
	inventory_image = "fireflower.png",
})

minetest.register_node(":qt:fireflower_plant_1", {
	description = "Fireflower Plant 1(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_1.png"},
	inventory_image = "fireflower_1.png",
	wield_image = "fireflower_1.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {"qt:fireflower_seeds"}
})

minetest.register_node(":qt:fireflower_plant_2", {
	description = "Fireflower Plant 2(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_2.png"},
	inventory_image = "fireflower_2.png",
	wield_image = "fireflower_2.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {"qt:fireflower_seeds"}
})

minetest.register_node(":qt:fireflower_plant_3", {
	description = "Fireflower Plant 3(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_3.png"},
	inventory_image = "fireflower_3.png",
	wield_image = "fireflower_3.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {
		max_items = 5,
		items = {
			{
				items = {'qt:fireflower_seeds 3'},
			},
			{
				items = {'qt:fireflower'},
			},
			{
				items = {'qt:fireflower'},
				rarity = 10
			}
		}
	},
})


minetest.register_node(":qt:nether_glass", {
	description = "Nether Glass",
	drawtype = "glasslike_framed_optional",
	tiles = {"nether_glass.png", "nether_glass_joined.png"},
	paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	sounds = default.node_sound_glass_defaults(),
	groups = {cracky=3,oddly_breakable_by_hand=3},
})

xpanes.register_pane("nether_pane", {
	description = "Nether Glass Pane",
	textures = {"nether_glass.png","nether_glass.png","nether_glass_side.png"},
	inventory_image = "nether_glass.png",
	wield_image = "nether_glass.png",
	sounds = default.node_sound_glass_defaults(),
	groups = {snappy=2, cracky=3, oddly_breakable_by_hand=3, pane=1},
	recipe = {
		{"qt:nether_glass", "qt:nether_glass", "qt:nether_glass"},
		{"qt:nether_glass", "qt:nether_glass", "qt:nether_glass"}
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:nether_glass",
	recipe = "qt:nether_sand",
})

minetest.register_node(":qt:jade_ore", {
	description = "Jade Ore",
	tiles = {"default_stone.png^jade_ore.png"},
	groups = {cracky=3},
	sounds = default_stone_sounds,
	drop = "qt:jade"
})

minetest.register_craftitem(":qt:jade", {
	description = "Jade Lump",
	inventory_image = "jade.png",
})

minetest.register_node(":qt:jade_block", {
	description = "Jade Block",
	tiles = {"jade_block.png"},
	is_ground_content = false,
	groups = {cracky=1,},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:jade_block',
	recipe = {
		{'qt:jade', 'qt:jade', 'qt:jade'},
		{'qt:jade', 'qt:jade', 'qt:jade'},
		{'qt:jade', 'qt:jade', 'qt:jade'},
	}
})

minetest.register_craft({
	output = 'qt:jade 9',
	recipe = {
		{'qt:jade_block'},
	}
})

minetest.register_node(":qt:nether_stone_with_dark_diamond", {
	description = "Dark Diamond Ore",
	tiles = {"dark_diamond_ore.png^nether_stone.png^dark_diamond_ore.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	drop = "qt:dark_diamond_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:dark_diamond_lump", {
	description = "Dark Diamond Lump",
	inventory_image = "dark_diamond.png",
})

minetest.register_node(":qt:dark_diamond_block", {
	description = "Dark Diamond Block",
	tiles = {"dark_diamond_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "qt:stratite_block_enriched"})
	end,
})

minetest.register_craft({
	output = 'qt:dark_diamond_block',
	recipe = {
		{'qt:dark_diamond_lump', 'qt:dark_diamond_lump', 'qt:dark_diamond_lump'},
		{'qt:dark_diamond_lump', 'qt:dark_diamond_lump', 'qt:dark_diamond_lump'},
		{'qt:dark_diamond_lump', 'qt:dark_diamond_lump', 'qt:dark_diamond_lump'},
	}
})

minetest.register_craft({
	output = 'qt:dark_diamond_lump 9',
	recipe = {
		{'qt:dark_diamond_block'},
		}
})





--poison nodes
--[[
minetest.register_node(":qt:poison_", {
	description = "",
	drawtype = "plantlike",
	waving = 1,
	tiles = {".png"},
	inventory_image = ".png",
	wield_image = ".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flora=1,attached_node=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
--]]
minetest.register_node(":qt:poison_reeds", {
	description = "Poison Reeds",
	drawtype = "plantlike",
	tiles = {"reeds.png"},
	inventory_image = "reeds.png",
	wield_image = "reeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.5, 0.3}
	},
	groups = {snappy=3,flammable=2, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),

	after_dig_node = function(pos, node, metadata, digger)
		default.dig_up(pos, node, digger)
	end,
})

--grass

minetest.register_node(":qt:poison_grass1", {
	description = "Poison Grass",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"grass1.png"},
	inventory_image = "grass3.png",
	wield_image = "grass3.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_grass")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_grass", "qt:poison_grass1")
rgen.register_random_data("P_grass", "qt:poison_grass2")
rgen.register_random_data("P_grass", "qt:poison_grass3")

for i = 2, 3 do
minetest.register_node(":qt:poison_grass"..i, {
	description = "Poison Grass",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"grass"..i..".png"},
	inventory_image = "grass"..i..".png",
	wield_image = "grass"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_grass1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--bushes

minetest.register_node(":qt:poison_bush1", {
	description = "Poison Bush",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"bush1.png"},
	inventory_image = "bush1.png",
	wield_image = "bush1.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		--minetest.debug("runs function")
		local node = rgen.get_random_data("P_bush")
		--minetest.debug("gets random data")
		minetest.set_node({x=pointed_thing.above.x, y=pointed_thing.above.y, z=pointed_thing.above.z, }, {name = node})
		--minetest.debug("places node")
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		--minetest.debug("takes item")
		return itemstack
	end,
})

rgen.register_random_data("P_bush", "qt:poison_bush1")
rgen.register_random_data("P_bush", "qt:poison_bush2")
rgen.register_random_data("P_bush", "qt:poison_bush3")
rgen.register_random_data("P_bush", "qt:poison_bush4")
rgen.register_random_data("P_bush", "qt:poison_bush5")
rgen.register_random_data("P_bush", "qt:poison_bush6")

for i = 2, 6 do
minetest.register_node(":qt:poison_bush"..i, {
	description = "Poison Bush",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"bush"..i..".png"},
	inventory_image = "bush"..i..".png",
	wield_image = "bush"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_bush1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--light plant

minetest.register_node(":qt:poison_light_plant1", {
	description = "Poison Light Plant",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"light_plant1.png"},
	inventory_image = "light_plant4.png",
	wield_image = "light_plant4.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	light_source = 8,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_light_plant")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_light_plant", "qt:poison_light_plant1")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant2")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant3")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant4")

for i = 2, 4 do
minetest.register_node(":qt:poison_light_plant"..i, {
	description = "Poison Light Plant",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"light_plant"..i..".png"},
	inventory_image = "light_plant"..i..".png",
	wield_image = "light_plant"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	light_source = 8,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_light_plant1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--tuber

minetest.register_node(":qt:poison_tuber1", {
	description = "Poison Tuber",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"tuber1.png"},
	inventory_image = "tuber3.png",
	wield_image = "tuber3.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_tuber")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_tuber", "qt:poison_tuber1")
rgen.register_random_data("P_tuber", "qt:poison_tuber2")
rgen.register_random_data("P_tuber", "qt:poison_tuber3")
rgen.register_random_data("P_tuber", "qt:poison_tuber4")
rgen.register_random_data("P_tuber", "qt:poison_tuber5")

for i = 2, 5 do
minetest.register_node(":qt:poison_tuber"..i, {
	description = "Poison Tuber",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"tuber"..i..".png"},
	inventory_image = "tuber"..i..".png",
	wield_image = "tuber"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_tuber1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--weed

minetest.register_node(":qt:poison_weed1", {
	description = "Poison Weed",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"weed1.png"},
	inventory_image = "weed1.png",
	wield_image = "weed1.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_weed")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_weed", "qt:poison_weed1")
rgen.register_random_data("P_weed", "qt:poison_weed2")
rgen.register_random_data("P_weed", "qt:poison_weed3")
rgen.register_random_data("P_weed", "qt:poison_weed4")
rgen.register_random_data("P_weed", "qt:poison_weed5")
rgen.register_random_data("P_weed", "qt:poison_weed6")

for i = 2, 6 do
minetest.register_node(":qt:poison_weed"..i, {
	description = "Poison Weed",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"weed"..i..".png"},
	inventory_image = "weed"..i..".png",
	wield_image = "weed"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_weed1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end



--P_plants
rgen.register_random_data("P_plants", "qt:poison_grass1")
rgen.register_random_data("P_plants", "qt:poison_grass2")
rgen.register_random_data("P_plants", "qt:poison_grass3")
rgen.register_random_data("P_plants", "qt:poison_bush1")
rgen.register_random_data("P_plants", "qt:poison_bush2")
rgen.register_random_data("P_plants", "qt:poison_bush3")
rgen.register_random_data("P_plants", "qt:poison_bush4")
rgen.register_random_data("P_plants", "qt:poison_bush5")
rgen.register_random_data("P_plants", "qt:poison_bush6")
rgen.register_random_data("P_plants", "qt:poison_light_plant1")
rgen.register_random_data("P_plants", "qt:poison_light_plant2")
rgen.register_random_data("P_plants", "qt:poison_light_plant3")
rgen.register_random_data("P_plants", "qt:poison_light_plant4")
rgen.register_random_data("P_plants", "qt:poison_tuber1")
rgen.register_random_data("P_plants", "qt:poison_tuber2")
rgen.register_random_data("P_plants", "qt:poison_tuber3")
rgen.register_random_data("P_plants", "qt:poison_tuber4")
rgen.register_random_data("P_plants", "qt:poison_tuber5")
rgen.register_random_data("P_plants", "qt:poison_weed1")
rgen.register_random_data("P_plants", "qt:poison_weed2")
rgen.register_random_data("P_plants", "qt:poison_weed3")
rgen.register_random_data("P_plants", "qt:poison_weed4")
rgen.register_random_data("P_plants", "qt:poison_weed5")
rgen.register_random_data("P_plants", "qt:poison_weed6")
rgen.register_random_data("P_plants", "qt:poison_reeds")

rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)


minetest.register_node(":qt:poison_stone", {
	description = "Poison Stone",
	tiles = {"poison_stone.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("poison_stone", "qt:poison_stone",
		{cracky = 3},
		{"poison_stone.png"},
		"Poison Stone Stair",
		"Poison Stone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:poison_dirt", {
	description = "Poison Dirt",
	tiles = {"poison_dirt.png"},
	groups = {crumbly=3,soil=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node(":qt:poison_dirt_with_grass", {
	description = "Poison Dirt with Grass",
	tiles = {"poison_grass.png", "poison_dirt.png",
		{name = "poison_dirt.png^poison_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly=3,soil=1},
	drop = 'qt:poison_dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.25},
	}),
})

function grow_poison_reeds(pos, node)
	pos.y = pos.y - 1
	local name = minetest.get_node(pos).name
	if name ~= "qt:poison_dirt_with_grass" and name ~= "qt:poison_dirt" then
		return
	end
	if not minetest.find_node_near(pos, 3, {"group:poison"}) then
		return
	end
	pos.y = pos.y + 1
	local height = 0
	while node.name == "qt:poison_reeds" and height < 6 do
		height = height + 1
		pos.y = pos.y + 1
		node = minetest.get_node(pos)
	end
	if height == 6 or node.name ~= "air" then
		return
	end
	minetest.set_node(pos, {name = "qt:poison_reeds"})
	return true
end

minetest.register_abm({
	nodenames = {"qt:poison_reeds"},
	neighbors = {"qt:poison_dirt", "qt:poison_dirt_with_grass"},
	interval = 50,
	chance = 20,
	action = function(...)
		grow_poison_reeds(...)
	end
})

minetest.register_abm({
	nodenames = {"qt:poison_dirt"},
	interval = 2,
	chance = 200,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if nodedef and (nodedef.sunlight_propagates or nodedef.paramtype == "light") and
				nodedef.liquidtype == "none" and
				(minetest.get_node_light(above) or 0) >= 13 then
			minetest.set_node(pos, {name = "qt:poison_dirt_with_grass"})
		end
	end
})

minetest.register_abm({
	nodenames = {"qt:poison_dirt_with_grass"},
	interval = 2,
	chance = 20,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if name ~= "ignore" and nodedef and not ((nodedef.sunlight_propagates or
				nodedef.paramtype == "light") and
				nodedef.liquidtype == "none") then
			minetest.set_node(pos, {name = "qt:poison_dirt"})
		end
	end
})

minetest.register_node(":qt:poison_stone_with_stratite", {
	description = "Stratite Ore",
	tiles = {"stratite_ore.png^poison_stone.png^stratite_ore.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	drop = "qt:stratite_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:stratite_lump", {
	description = "Stratite Lump",
	inventory_image = "stratite_lump.png",
})

minetest.register_node(":qt:stratite_block", {
	description = "Stratite Block",
	tiles = {"stratite_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	on_lightning_strike = function(pos, dist)
		minetest.set_node(pos, {name = "qt:stratite_block_enriched"})
	end,
})

minetest.register_craft({
	output = 'qt:stratite_block',
	recipe = {
		{'qt:stratite_lump', 'qt:stratite_lump', 'qt:stratite_lump'},
		{'qt:stratite_lump', 'qt:stratite_lump', 'qt:stratite_lump'},
		{'qt:stratite_lump', 'qt:stratite_lump', 'qt:stratite_lump'},
	}
})

minetest.register_craft({
	output = 'qt:stratite_lump 9',
	recipe = {
		{'qt:stratite_block'},
		}
})

minetest.register_craftitem(":qt:stratite_lump_enriched", {
	description = "Enriched Stratite Lump",
	inventory_image = "stratite_lump_enriched.png",
})

minetest.register_node(":qt:stratite_block_enriched", {
	description = "Enriched Stratite Block",
	tiles = {"stratite_block_enriched.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:stratite_block_enriched',
	recipe = {
		{'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched'},
		{'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched'},
		{'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched', 'qt:stratite_lump_enriched'},
	}
})

minetest.register_craft({
	output = 'qt:stratite_lump_enriched 9',
	recipe = {
		{'qt:stratite_block_enriched'},
		}
})

minetest.register_tool(":qt:wand_stratite", {
	description = "Stratite Wand",
	inventory_image = "stratite_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			local node_dat = minetest.registered_nodes[minetest.get_node(pointed_thing.under).name]
			if node_dat.groups.antimagic == nil then
				qt.strike_lightning(pointed_thing.above)
				itemstack:add_wear(65535/15000)
			end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:wand_stratite',
	recipe = {
		{'qt:stratite_lump'},
		{'qt:gold_stick'},
		{'qt:gold_stick'},
	}
})



qt.register_liquid("qt:poison_liquid", {
description = "Poison Liquid",
tiles = {inventory = "poison_liquid.png", source_animated="poison_liquid_source_animated.png", flowing_animated="poison_liquid_flowing_animated.png", bucket="bucket_poison.png"},
alpha = 160,
drowning = 1,
viscosity = 1,
renewable = true,
range = 8,
damage_per_second = 10,
post_effect_color = {a=120, r=76, g=187, b=106}, --
custom_groups = {poison=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=0},
custom_groups_flowing = {poison=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=1},
})



minetest.register_node(":qt:poison_gem_sponge", {
	description = "Poison Gem Sponge",
	tiles = {"poison_sponge.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
	drop = 'qt:poison_gem',
})

minetest.register_craftitem(":qt:poison_gem", {
	description = "Poison Gem",
	inventory_image = "poison_gem.png",
})

minetest.register_node(":qt:poison_gem_block", {
	description = "Poison Gem Block",
	tiles = {"poison_gem_block.png"},
	is_ground_content = false,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:poison_gem_block',
	recipe = {
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
	}
})

minetest.register_craft({
	output = 'qt:poison_gem 9',
	recipe = {
		{'qt:poison_gem_block'},
	}
})


minetest.register_abm({
	nodenames = {"qt:poison_liquid_flowing"},
	neighbors = {"group:lava"},
	interval = 1,
	chance = 2,
	action = function(...)
		cool_poison(...)
	end,
})

minetest.register_abm({
	nodenames = {"qt:poison_liquid_source"},
	neighbors = {"group:lava"},
	interval = 1,
	chance = 2,
	action = function(...)
		cool_poison(...)
	end,
})

cool_poison = function(pos)
	minetest.set_node(pos, {name = "qt:poison_gem_sponge"})
	minetest.sound_play("default_cool_lava",
		{pos = pos, max_hear_distance = 16, gain = 0.25})
end

minetest.register_craftitem(":qt:poison_droplet", {
	description = "Poison Droplet",
	inventory_image = "poison_droplet.png",
})

--murite

qt.register_liquid("qt:mercury", {
description = "Mercury",
tiles = {inventory = "mercury.png", source_animated="mercury_source_animated.png", flowing_animated="mercury_flowing_animated.png", bucket="bucket_mercury.png"},
alpha = 255,
drowning = 1,
viscosity = 1,
renewable = false,
range = 5,
damage_per_second = 12,
light_source = 12,
post_effect_color = {a=200, r=159, g=159, b=159}, --
custom_groups = {liquid=3, puts_out_fire=3, not_in_creative_inventory=0},
custom_groups_flowing = {liquid=3, puts_out_fire=3, not_in_creative_inventory=1},
})

minetest.register_node(":qt:murite_stone", {
	description = "Murite Stone",
	tiles = {"murite_stone.png"},
	groups = {cracky=3, stone=1, murite=1},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("murite_stone", "qt:murite_stone",
		{cracky = 3},
		{"murite_stone.png"},
		"Murite Stone Stair",
		"Murite Stone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:murite_stone_with_crystal", {
	description = "Murite Crystal Ore",
	tiles = {"murite_stone.png^murite_crystal_ore.png"},
	groups = {cracky=3, stone=1, murite=1},
	legacy_mineral = true,
	drop = 'qt:murite_crystal 2',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":qt:murite_gravel", {
	description = "Murite Gravel",
	tiles = {"murite_gravel.png"},
	groups = {crumbly = 2, falling_node = 1, murite=1},
	sounds = default.node_sound_gravel_defaults(),
})

minetest.register_node(":qt:murite_crystal", {
	description = "Murite Crystal",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"murite_crystal.png"},
	inventory_image = "murite_crystal.png",
	wield_image = "murite_crystal.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	light_source = 12,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
	},
	groups = {snappy=2,dig_immediate=3,attached_node=1, murite=1},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_abm({
	nodenames = {"qt:murite_gravel"},
	neighbors = {"qt:mercury_source"},
	interval = 1,
	chance = 50,
	action = function(pos)
		local npos = {x = pos.x, y = pos.y+1, z = pos.z}
		local node = minetest.get_node(npos)
		if node.name == "air" then
			minetest.set_node(npos, {name = "qt:murite_crystal"})
		end
	end,
})

--brilliance
--1st sky dimention

minetest.register_node(":qt:brilliance_stone", {
	description = "Brilliance Stone",
	tiles = {"brilliance_stone.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	drop = 'qt:brilliance_cobble',
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("brilliance_stone", "qt:brilliance_stone",
		{cracky = 3},
		{"brilliance_stone.png"},
		"Brilliance Stone Stair",
		"Brilliance Stone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:brilliance_cobble", {
	description = "Brilliance Cobblestone",
	tiles = {"brilliance_cobble.png"},
	is_ground_content = false,
	groups = {cracky=3, stone=2, brilliance=1},
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("brilliance_cobble", "qt:brilliance_cobble",
		{cracky = 3},
		{"brilliance_cobble.png"},
		"Brilliance Cobblestone Stair",
		"Brilliance Cobblestone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:brilliance_stonebrick", {
	description = "Brilliance Stone Brick",
	tiles = {"brilliance_stone_brick.png"},
	is_ground_content = false,
	groups = {cracky=2, stone=1, brilliance=1},
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("brilliance_stonebrick", "qt:brilliance_stonebrick",
		{cracky = 3},
		{"brilliance_stone_brick.png"},
		"Brilliance Stone Brick Stair",
		"Brilliance Stone Brick Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:brilliance_dirt", {
	description = "Brilliance Dirt",
	tiles = {"brilliance_dirt.png"},
	groups = {crumbly=3,soil=1, brilliance=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node(":qt:brilliance_dirt_with_grass", {
	description = "Brilliance Dirt with Grass",
	tiles = {"brilliance_grass.png", "brilliance_dirt.png",
		{name = "brilliance_dirt.png^brilliance_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly=3,soil=1, brilliance=1},
	drop = 'qt:brilliance_dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.25},
	}),
})

minetest.register_node(":qt:brilliance_sand", {
	description = "Brilliance Sand",
	tiles = {"brilliance_sand.png"},
	groups = {crumbly=3, falling_node=1, sand=1, brilliance=1},
	sounds = default.node_sound_sand_defaults(),
})


minetest.register_craft({
	output = 'qt:brilliance_stonebrick 4',
	recipe = {
		{'qt:brilliance_stone', 'qt:brilliance_stone'},
		{'qt:brilliance_stone', 'qt:brilliance_stone'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:brilliance_stone",
	recipe = "qt:brilliance_cobble",
})

minetest.register_abm({
	nodenames = {"qt:brilliance_dirt"},
	interval = 2,
	chance = 200,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if nodedef and (nodedef.sunlight_propagates or nodedef.paramtype == "light") and
				nodedef.liquidtype == "none" and
				(minetest.get_node_light(above) or 0) >= 13 then
				minetest.set_node(pos, {name = "qt:brilliance_dirt_with_grass"})
		end
	end
})

minetest.register_abm({
	nodenames = {"qt:brilliance_dirt_with_grass"},
	interval = 2,
	chance = 20,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if name ~= "ignore" and nodedef and not ((nodedef.sunlight_propagates or
				nodedef.paramtype == "light") and
				nodedef.liquidtype == "none") then
			minetest.set_node(pos, {name = "qt:brilliance_dirt"})
		end
	end
})

minetest.register_node(":qt:brilliance_tree", {
	description = "Brilliance Tree",
	tiles = {"brilliance_tree_top.png", "brilliance_tree_top.png", "brilliance_tree.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree=1,choppy=2,oddly_breakable_by_hand=1,flammable=2, brilliance=1},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node(":qt:brilliance_leaves", {
	description = "Brilliance Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	visual_scale = 1.3,
	tiles = {"brilliance_leaves.png"},
	special_tiles = {"brilliance_leaves.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy=3, leafdecay=3, flammable=2, leaves=1, brilliance=1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'qt:brilliance_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'qt:brilliance_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":qt:brilliance_wood", {
	description = "Brilliance Wooden Planks",
	tiles = {"brilliance_wood.png"},
	is_ground_content = false,
	groups = {choppy=2,oddly_breakable_by_hand=2,flammable=3,wood=1, brilliance=1},
	sounds = default.node_sound_wood_defaults(),
})

stairs.register_stair_and_slab("brilliance_wood", "qt:brilliance_wood",
		{cracky = 3},
		{"brilliance_wood.png"},
		"Brilliance Wood Stair",
		"Brilliance Wood Slab",
		default.node_sound_stone_defaults())

default.register_fence(":qt:fence_brilliance_wood", {
	description = "Brilliance Wood Fence",
	texture = "brilliance_wood_fence.png",
	material = "qt:brilliance_wood",
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2},
	sounds = default.node_sound_wood_defaults()
})

minetest.register_craft({
	output = 'qt:brilliance_wood 4',
	recipe = {
		{'qt:brilliance_tree'},
	}
})

minetest.register_node(":qt:brilliance_sapling", {
	description = "Brilliance Sapling",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"brilliance_sapling.png"},
	inventory_image = "brilliance_sapling.png",
	wield_image = "brilliance_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
	},
	groups = {snappy=2,dig_immediate=3,flammable=2,attached_node=1,sapling=1, brilliance=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":qt:brilliance_sapling_instant", {
	description = "Brilliance Sapling Instant-growing",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"brilliance_sapling.png"},
	inventory_image = "brilliance_sapling.png",
	wield_image = "brilliance_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
	},
	groups = {snappy=2,dig_immediate=3,flammable=2,attached_node=1,sapling=1, brilliance=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":qt:brilliance_glass", {
	description = "Brilliance Glass",
	drawtype = "glasslike_framed_optional",
	tiles = {"brilliance_glass.png", "brilliance_glass_framed.png"},
	inventory_image = minetest.inventorycube("brilliance_glass.png"),
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky=3,oddly_breakable_by_hand=3, brilliance=1},
	sounds = default.node_sound_glass_defaults(),
})

xpanes.register_pane("brilliance_pane", {
	description = "Brilliance Glass Pane",
	textures = {"brilliance_glass.png","brilliance_glass.png","brilliance_glass_side.png"},
	inventory_image = "brilliance_glass.png",
	wield_image = "brilliance_glass.png",
	sounds = default.node_sound_glass_defaults(),
	groups = {snappy=2, cracky=3, oddly_breakable_by_hand=3, pane=1},
	recipe = {
		{"qt:brilliance_glass", "qt:brilliance_glass", "qt:brilliance_glass"},
		{"qt:brilliance_glass", "qt:brilliance_glass", "qt:brilliance_glass"}
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:brilliance_glass",
	recipe = "qt:brilliance_sand",
})

minetest.register_node(":qt:brilliance_stone_with_lilimite", {
	description = "Lilimite Ore",
	tiles = {"lilimite_ore.png^brilliance_stone.png^lilimite_ore.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	legacy_mineral = true,
	drop = "qt:lilimite_dust",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:lilimite_dust", {
	description = "Lilimite Dust",
	inventory_image = "lilimite_dust.png",
})

minetest.register_node(":qt:lilimite_block", {
	description = "Lilimite Block",
	tiles = {"lilimite_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:lilimite_block',
	recipe = {
		{'qt:lilimite_dust', 'qt:lilimite_dust', 'qt:lilimite_dust'},
		{'qt:lilimite_dust', 'qt:lilimite_dust', 'qt:lilimite_dust'},
		{'qt:lilimite_dust', 'qt:lilimite_dust', 'qt:lilimite_dust'},
	}
})

minetest.register_craft({
	output = 'qt:lilimite_dust 9',
	recipe = {
		{'qt:lilimite_block'},
		}
})

--qt:yellow_slime_bucket
--bucket:bucket_river_water

minetest.register_craft({
	output = 'qt:yellow_slime_bucket',
	recipe = {
		{'qt:lilimite_dust', 'qt:lilimite_dust', 'qt:lilimite_dust'},
		{'qt:lilimite_dust', 'bucket:bucket_river_water', 'qt:lilimite_dust'},
		{'qt:lilimite_dust', 'qt:lilimite_dust', 'qt:lilimite_dust'},
	}
})



minetest.register_node(":qt:brilliance_stone_with_cobalt", {
	description = "Cobalt Ore",
	tiles = {"cobalt_ore.png^brilliance_stone.png^cobalt_ore.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	legacy_mineral = true,
	drop = "qt:cobalt_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:cobalt_lump", {
	description = "Cobalt Lump",
	inventory_image = "cobalt_lump.png",
})

minetest.register_craft({
	type = "cooking",
	output = "qt:cobalt_ingot",
	recipe = "qt:cobalt_lump",
})


minetest.register_craftitem(":qt:cobalt_ingot", {
	description = "Cobalt Ingot",
	inventory_image = "cobalt_ingot.png",
})

minetest.register_node(":qt:cobalt_block", {
	description = "Cobalt Block",
	tiles = {"cobalt_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:cobalt_block',
	recipe = {
		{'qt:cobalt_ingot', 'qt:cobalt_ingot', 'qt:cobalt_ingot'},
		{'qt:cobalt_ingot', 'qt:cobalt_ingot', 'qt:cobalt_ingot'},
		{'qt:cobalt_ingot', 'qt:cobalt_ingot', 'qt:cobalt_ingot'},
	}
})

minetest.register_craft({
	output = 'qt:cobalt_ingot 9',
	recipe = {
		{'qt:cobalt_block'},
		}
})

minetest.register_node(":qt:brilliance_wildflower", {
	description = "Brilliance Wildflower",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"brilliance_wildflower.png"},
	inventory_image = "brilliance_wildflower.png",
	wield_image = "brilliance_wildflower.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, brilliance=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})

--Etheral

minetest.register_node(":qt:etheral_stone", {
	description = "Etheral Stone",
	tiles = {"etheral_stone.png"},
	groups = {cracky=3, stone=1, etheral=1},
	drop = 'qt:etheral_cobble',
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("etheral_stone", "qt:etheral_stone",
		{cracky = 3},
		{"etheral_stone.png"},
		"Etheral Stone Stair",
		"Etheral Stone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:etheral_cobble", {
	description = "Etheral Cobblestone",
	tiles = {"etheral_cobble.png"},
	is_ground_content = false,
	groups = {cracky=3, stone=2, etheral=1},
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("etheral_cobble", "qt:etheral_cobble",
		{cracky = 3},
		{"etheral_cobble.png"},
		"Etheral Cobblestone Stair",
		"Etheral Cobblestone Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:etheral_stonebrick", {
	description = "Etheral Stone Brick",
	tiles = {"etheral_stone_brick.png"},
	is_ground_content = false,
	groups = {cracky=2, stone=1, etheral=1},
	sounds = default.node_sound_stone_defaults(),
})

stairs.register_stair_and_slab("etheral_stonebrick", "qt:etheral_stonebrick",
		{cracky = 3},
		{"etheral_stone_brick.png"},
		"Etheral Stone Brick Stair",
		"Etheral Stone Brick Slab",
		default.node_sound_stone_defaults())

minetest.register_node(":qt:etheral_stone_with_corilium", {
	description = "Corilium Ore",
	tiles = {"corilium_ore.png^etheral_stone.png^corilium_ore.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	legacy_mineral = true,
	drop = "qt:corilium_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:corilium_lump", {
	description = "Corilium Lump",
	inventory_image = "corilium_lump.png",
})

minetest.register_craft({
	type = "cooking",
	output = "qt:corilium_ingot",
	recipe = "qt:corilium_lump",
})

minetest.register_node(":qt:etheral_stone_with_carbite", {
	description = "Carbite Ore",
	tiles = {"carbite_ore.png^etheral_stone.png^carbite_ore.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	legacy_mineral = true,
	drop = "qt:carbite_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:carbite_lump", {
	description = "Carbite Lump",
	inventory_image = "carbite_lump.png",
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:carbite_lump",
	burntime = 150,
})

minetest.register_node(":qt:carbite_block", {
	description = "Carbite Block",
	tiles = {"carbite_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:carbite_block',
	recipe = {
		{'qt:carbite_lump', 'qt:carbite_lump', 'qt:carbite_lump'},
		{'qt:carbite_lump', 'qt:carbite_lump', 'qt:carbite_lump'},
		{'qt:carbite_lump', 'qt:carbite_lump', 'qt:carbite_lump'},
	}
})

minetest.register_craft({
	output = 'qt:carbite_lump 9',
	recipe = {
		{'qt:carbite_block'},
		}
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:carbite_block",
	burntime = 1350,
})

minetest.register_node(":qt:etheral_stone_with_steelium", {
	description = "Steelium Ore",
	tiles = {"steelium_ore.png^etheral_stone.png^steelium_ore.png"},
	groups = {cracky=3, stone=1, brilliance=1},
	legacy_mineral = true,
	drop = "qt:steelium_lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:steelium_lump", {
	description = "Steelium Lump",
	inventory_image = "steelium_lump.png",
})

minetest.register_craftitem(":qt:steelium_ingot", {
	description = "Steelium Ingot",
	inventory_image = "steelium_ingot.png",
})


minetest.register_craft({
	type = "cooking",
	output = "qt:steelium_ingot",
	recipe = "qt:steelium_lump",
})

minetest.register_node(":qt:steelium_block", {
	description = "Steelium Block",
	tiles = {"steelium_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:steelium_block',
	recipe = {
		{'qt:steelium_ingot', 'qt:steelium_ingot', 'qt:steelium_ingot'},
		{'qt:steelium_ingot', 'qt:steelium_ingot', 'qt:steelium_ingot'},
		{'qt:steelium_ingot', 'qt:steelium_ingot', 'qt:steelium_ingot'},
	}
})

minetest.register_craft({
	output = 'qt:steelium_ingot 9',
	recipe = {
		{'qt:steelium_block'},
		}
})

minetest.register_node(":qt:etheral_dirt", {
	description = "Etheral Dirt",
	tiles = {"etheral_dirt.png"},
	groups = {crumbly=3,soil=1, etheral=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node(":qt:etheral_dirt_with_grass", {
	description = "Etheral Dirt with Grass",
	tiles = {"etheral_grass.png", "etheral_dirt.png",
		{name = "etheral_dirt.png^etheral_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly=3,soil=1, etheral=1},
	drop = 'qt:etheral_dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.25},
	}),
})

minetest.register_node(":qt:etheral_sand", {
	description = "etheral Sand",
	tiles = {"etheral_sand.png"},
	groups = {crumbly=3, falling_node=1, sand=1, etheral=1},
	sounds = default.node_sound_sand_defaults(),
})


minetest.register_craft({
	output = 'qt:etheral_stonebrick 4',
	recipe = {
		{'qt:etheral_stone', 'qt:etheral_stone'},
		{'qt:etheral_stone', 'qt:etheral_stone'},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:etheral_stone",
	recipe = "qt:etheral_cobble",
})

minetest.register_abm({
	nodenames = {"qt:etheral_dirt"},
	interval = 2,
	chance = 200,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if nodedef and (nodedef.sunlight_propagates or nodedef.paramtype == "light") and
				nodedef.liquidtype == "none" and
				(minetest.get_node_light(above) or 0) >= 13 then
				minetest.set_node(pos, {name = "qt:etheral_dirt_with_grass"})
		end
	end
})

minetest.register_abm({
	nodenames = {"qt:etheral_dirt_with_grass"},
	interval = 2,
	chance = 20,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if name ~= "ignore" and nodedef and not ((nodedef.sunlight_propagates or
				nodedef.paramtype == "light") and
				nodedef.liquidtype == "none") then
			minetest.set_node(pos, {name = "qt:etheral_dirt"})
		end
	end
})

minetest.register_node(":qt:etheral_tree", {
	description = "Etheral Tree",
	tiles = {"etheral_tree_top.png", "etheral_tree_top.png", "etheral_tree.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {tree=1,choppy=2,oddly_breakable_by_hand=1,flammable=2, etheral=1},
	sounds = default.node_sound_wood_defaults(),

	on_place = minetest.rotate_node
})

minetest.register_node(":qt:etheral_leaves", {
	description = "Etheral Leaves",
	drawtype = "allfaces_optional",
	waving = 1,
	visual_scale = 1.3,
	tiles = {"etheral_leaves.png"},
	special_tiles = {"etheral_leaves.png"},
	paramtype = "light",
	is_ground_content = false,
	groups = {snappy=3, leafdecay=3, flammable=2, leaves=1, etheral=1},
	drop = {
		max_items = 1,
		items = {
			{
				-- player will get sapling with 1/20 chance
				items = {'qt:etheral_sapling'},
				rarity = 20,
			},
			{
				-- player will get leaves only if he get no saplings,
				-- this is because max_items is 1
				items = {'qt:etheral_leaves'},
			}
		}
	},
	sounds = default.node_sound_leaves_defaults(),

	after_place_node = default.after_place_leaves,
})

minetest.register_node(":qt:etheral_wood", {
	description = "Etheral Wooden Planks",
	tiles = {"etheral_wood.png"},
	is_ground_content = false,
	groups = {choppy=2,oddly_breakable_by_hand=2,flammable=3,wood=1, etheral=1},
	sounds = default.node_sound_wood_defaults(),
})

stairs.register_stair_and_slab("etheral_wood", "qt:etheral_wood",
		{cracky = 3},
		{"etheral_wood.png"},
		"Etheral Wood Stair",
		"Etheral Wood Slab",
		default.node_sound_stone_defaults())

default.register_fence(":qt:fence_etheral_wood", {
	description = "Etheral Wood Fence",
	texture = "etheral_wood_fence.png",
	material = "qt:etheral_wood",
	groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2},
	sounds = default.node_sound_wood_defaults()
})

minetest.register_craft({
	output = 'qt:etheral_wood 4',
	recipe = {
		{'qt:etheral_tree'},
	}
})

minetest.register_node(":qt:etheral_sapling", {
	description = "Etheral Sapling",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"etheral_sapling.png"},
	inventory_image = "etheral_sapling.png",
	wield_image = "etheral_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
	},
	groups = {snappy=2,dig_immediate=3,flammable=2,attached_node=1,sapling=1, etheral=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":qt:etheral_sapling_instant", {
	description = "Etheral Sapling Instant-growing",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"etheral_sapling.png"},
	inventory_image = "etheral_sapling.png",
	wield_image = "etheral_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.35, 0.3}
	},
	groups = {snappy=2,dig_immediate=3,flammable=2,attached_node=1,sapling=1, etheral=1},
	sounds = default.node_sound_leaves_defaults(),
})

minetest.register_node(":qt:etheral_glass", {
	description = "Etheral Glass",
	drawtype = "glasslike_framed_optional",
	tiles = {"etheral_glass.png", "etheral_glass_framed.png"},
	inventory_image = minetest.inventorycube("etheral_glass.png"),
	paramtype = "light",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {cracky=3,oddly_breakable_by_hand=3, brilliance=1},
	sounds = default.node_sound_glass_defaults(),
})

xpanes.register_pane("etheral_pane", {
	description = "Etheral Glass Pane",
	textures = {"etheral_glass.png","etheral_glass.png","etheral_glass_side.png"},
	inventory_image = "etheral_glass.png",
	wield_image = "etheral_glass.png",
	sounds = default.node_sound_glass_defaults(),
	groups = {snappy=2, cracky=3, oddly_breakable_by_hand=3, pane=1},
	recipe = {
		{"qt:etheral_glass", "qt:etheral_glass", "qt:etheral_glass"},
		{"qt:etheral_glass", "qt:etheral_glass", "qt:etheral_glass"}
	}
})

minetest.register_craft({
	type = "cooking",
	output = "qt:etheral_glass",
	recipe = "qt:etheral_sand",
})

minetest.register_craftitem(":qt:composite_plate", {
	description = "Composite Plate",
	inventory_image = "composite_plate.png",
})

minetest.register_craft({
	output = 'qt:composite_plate',
	recipe = {
		{'qt:steelium_ingot', 'qt:steelium_ingot', 'qt:steelium_ingot'},
		{'qt:corilium_ingot', 'qt:corilium_ingot', 'qt:corilium_ingot'},
	}
})

minetest.register_craftitem(":qt:alien_circuit", {
	description = "Alien Circuit",
	inventory_image = "alien_circuit.png",
})

minetest.register_craft({
	output = 'qt:alien_circuit',
	recipe = {
		{'qt:etheral_glass', 'qt:corilium_ingot', 'qt:etheral_glass'},
		{'qt:etheral_glass', 'qt:etheral_glass', 'qt:etheral_glass'},
		{'qt:etheral_glass', 'qt:corilium_ingot', 'qt:etheral_glass'},
	}
})

--not_in_creative_inventory=1
