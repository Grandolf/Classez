qt_effects = {}
qt_effects.playerdat = {}

--this logs the active players and the editations to their physics
minetest.register_on_joinplayer(function(player)
	local playername = player:get_player_name()
	if playername ~= "" then
		if qt_effects.playerdat[playername] == nil then
			qt_effects.playerdat[playername] = {
				speed = 1.0, -- multiplier to default value
				jump = 1.0, -- multiplier to default value
				gravity = 1.0, -- multiplier to default value
				sneak = true, -- whether player can sneak
				sneak_glitch = true, -- whether player can use the sneak glitch
			}

			local effects = playereffects.get_player_effects(playername)
			if effects ~= nil then
				for e=1, #effects do
					local effect_name = effects[e].effect_id
					--log present effects
					if effect_name == "speed" then
						qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed + 1
					elseif effect_name == "speed_2" then
						qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed + 2
					elseif effect_name == "slowness" then
						qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed - 0.5
					elseif effect_name == "slowness_2" then
						qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed - 0.9
					elseif effect_name == "jump_boost" then
						qt_effects.playerdat[playername].jump = qt_effects.playerdat[playername].jump + 1
					elseif effect_name == "jump_boost_2" then
						qt_effects.playerdat[playername].jump = qt_effects.playerdat[playername].jump + 2
					elseif effect_name == "flying" then
						qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed + 2
						qt_effects.playerdat[playername].jump = qt_effects.playerdat[playername].gravity - 0.98
					end
				end
			end
		end
	end
end)

qt_effects.set_player_physics = function(player, table)
	local playername = player:get_player_name()
	if playername ~= "" then
		qt_effects.playerdat[playername].speed = qt_effects.playerdat[playername].speed + table.speed
		qt_effects.playerdat[playername].jump = qt_effects.playerdat[playername].jump + table.jump
		qt_effects.playerdat[playername].gravity = qt_effects.playerdat[playername].gravity + table.gravity
		qt_effects.playerdat[playername].sneak = table.sneak or true
		qt_effects.playerdat[playername].sneak_glitch = table.sneak_glitch or true

		player:set_physics_override(qt_effects.playerdat[playername].speed, qt_effects.playerdat[playername].jump, qt_effects.playerdat[playername].gravity, qt_effects.playerdat[playername].sneak, qt_effects.playerdat[playername].sneak_glitch)
	end
end
