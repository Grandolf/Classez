--[[
qt_mobs:register_mob(":qt:crystalman", {
	type = "monster",
	hp_max = 40,
	collisionbox = {-0.4, -0.2, -0.4, 0.4, 1.5, 0.4},
	textures = {"murite.png"},
	visual = "mesh",
	mesh = "murite.x",
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	walk_velocity = 1.5,
	run_velocity = 2.5,
	damage = 40,
	armor = 90,
	drops = {
		{name = "default:snow",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 10,
	lava_damage = 10,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 120,
		stand_start = 0,
		stand_end = 78,
		walk_start = 0,
		walk_end = 78,
	},
	view_range = 20,
	sounds = {
		random = "skeleton",
	},
	on_rightclick = nil,
})
--]]

qt_mobs:register_mob(":qt:crystalman", {
	type = "monster",
	hp_max = 50,
	collisionbox = {-0.4, -0.2, -0.4, 0.4, 1.5, 0.4},
	visual = "mesh",
	mesh = "murite.x",
	textures = {"murite.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 30,
	walk_velocity = 1.5,
	run_velocity = 2.2,
	damage = 40,
	drops ={
		{name = "qt:bone",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 90,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 120,
		stand_start = 0,
		stand_end = 78,
		walk_start = 0,
		walk_end = 78,
		run_start = 0,
		run_end = 78,
		punch_start = 0,
		punch_end = 78,
	},
	allience = "zombie",
	sounds = {
		random = "skeleton",
	},
})

qt_mobs:register_spawn("qt:crystalman", {"qt:murite_gravel", "qt:murite_stone"}, 7, -1, 1000, 3, -990)
qt_mobs:register_spawn("qt:crystalman", {"qt:murite_crystal"}, 7, -1, 200, 3, -990)


minetest.register_craftitem(":qt:spawn_crystalman", {
	description = "Spawn Crystalman",
	inventory_image = "spawn_crystalman.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:crystalman")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_crystalman", {
	description = "Crystalman Spawner",
	paramtype = "light",
	tiles = {"crystalman_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_crystalman"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:crystalman" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				--local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				--if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:crystalman")
			end
		end
	end
 })
end
