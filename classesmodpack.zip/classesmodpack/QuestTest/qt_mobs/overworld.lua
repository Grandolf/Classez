-- overworld mobs

minetest.register_craftitem(":qt:rotten_flesh", {
	description = "Zombie Flesh",
	inventory_image = "zombie_flesh.png",
	on_use = minetest.item_eat(-1),
})

minetest.register_craftitem(":qt:meat_raw", {
	description = "Freshly Dead Meat",
	inventory_image = "raw_meat.png",
	on_use = minetest.item_eat(1),
})

minetest.register_craftitem(":qt:meat", {
	description = "Freshly Roasted Meat",
	inventory_image = "meat.png",
	on_use = minetest.item_eat(7),
})

minetest.register_craft({
	type = "cooking",
	output = "qt:meat",
	recipe = "qt:meat_raw",
})

minetest.register_craftitem(":qt:bone", {
	description = "Bone",
	inventory_image = "bone.png",
	groups = {bone=1},
})

minetest.register_craftitem(":qt:armor_frag_diamond", {
	description = "Diamond Armor Fragments",
	inventory_image = "diamond_armor_frag.png",
})

minetest.register_craft({
	output = 'default:diamond 2',
	recipe = {
		{'qt:armor_frag_diamond'},
	}
})

minetest.register_craftitem(":qt:armor_frag_mese", {
	description = "Mese Armor Fragments",
	inventory_image = "gold_armor_frag.png",
})

minetest.register_craft({
	output = 'default:mese_crystal 2',
	recipe = {
		{'qt:armor_frag_mese'},
	}
})

minetest.register_craftitem(":qt:armor_frag_gold", {
	description = "Gold Armor Fragments",
	inventory_image = "gold_armor_frag.png",
})

minetest.register_craft({
	output = 'default:gold_ingot 2',
	recipe = {
		{'qt:armor_frag_gold'},
	}
})

minetest.register_craftitem(":qt:armor_frag_steel", {
	description = "Steel Armor Fragments",
	inventory_image = "steel_armor_frag.png",
})

minetest.register_craft({
	output = 'default:steel_ingot 2',
	recipe = {
		{'qt:armor_frag_steel'},
	}
})

minetest.register_craftitem(":qt:soul", {
	description = "Mob Soul",
	inventory_image = "soul.png",
})

minetest.register_craftitem(":qt:ent_eyeball", {
	description = "Ent Eyeball",
	inventory_image = "ent_eyeball.png",
})

minetest.register_craftitem(":qt:pumpkin_piece", {
	description = "Pumpkin Pieces",
	inventory_image = "pumpkin_piece.png",
	on_use = minetest.item_eat(6),
})

minetest.register_craftitem(":qt:skull", {
	description = "Skull",
	inventory_image = "skull.png",
})

minetest.register_craft({
	output = 'qt:skull',
	recipe = {
		{'group:bone','group:bone','group:bone'},
		{'group:bone','','group:bone'},
		{'group:bone','group:bone','group:bone'},
	}
})

qt_mobs:register_mob(":qt:zombie", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"zombie.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "default:steel_ingot",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 150,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})

qt_mobs:register_spawn("qt:zombie", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_zombie", {
	description = "Spawn Zombie",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:zombie")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_zombie", {
	description = "Zombie Spawner",
	paramtype = "light",
	tiles = {"zombie_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_zombie"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:zombie" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:zombie")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:zombie_armored", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"zombie_armored.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:armor_frag_steel",
		chance = 2,
		min = 1,
		max = 4,},
		{name = "qt:armor_frag_mese",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})
qt_mobs:register_spawn("qt:zombie_armored", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_zombie_armored", {
	description = "Spawn Armored Zombie",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:zombie_armored")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_zombie_armored", {
	description = "Armored Zombie Spawner",
	paramtype = "light",
	tiles = {"zombie_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_zombie_armored"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:zombie_armored" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:zombie_armored")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:zombie_elite", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"zombie_elite.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 1,
		max = 4,},
		{name = "qt:armor_frag_gold",
		chance = 2,
		min = 1,
		max = 4,},
		{name = "qt:armor_frag_diamond",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})
qt_mobs:register_spawn("qt:zombie_elite", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_zombie_elite", {
	description = "Spawn Elite Zombie",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:zombie_elite")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_zombie_elite", {
	description = "Elite Zombie Spawner",
	paramtype = "light",
	tiles = {"zombie_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_zombie_elite"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:zombie_elite" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:zombie_elite")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:skeleton", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"skeleton.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:bone",
		chance = 1,
		min = 2,
		max = 4,},
		{name = "default:steel_ingot",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 150,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "skeleton",
	sounds = {
		random = "skeleton",
	},
})
qt_mobs:register_spawn("qt:skeleton", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_skeleton", {
	description = "Spawn Skeleton",
	inventory_image = "spawn_skeleton.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:skeleton")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_skeleton", {
	description = "Skeleton Spawner",
	paramtype = "light",
	tiles = {"skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_skeleton"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:skeleton" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:skeleton")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:skeleton_advanced", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"skeleton_advanced.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:bone",
		chance = 1,
		min = 2,
		max = 4,},
		{name = "qt:armor_frag_steel",
		chance = 2,
		min = 1,
		max = 4,},
		{name = "qt:armor_frag_mese",
		chance = 20,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "skeleton",
	sounds = {
		random = "skeleton",
	},
})
qt_mobs:register_spawn("qt:skeleton_advanced", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_skeleton_advanced", {
	description = "Spawn Advanced Skeleton",
	inventory_image = "spawn_skeleton.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:skeleton_advanced")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_skeleton_advanced", {
	description = "Advanced Skeleton Spawner",
	paramtype = "light",
	tiles = {"skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_skeleton_advanced"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:skeleton_advanced" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:skeleton_advanced")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:skeleton_carbonized", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"skeleton_carbonic.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "default:coal_lump",
		chance = 1,
		min = 3,
		max = 6,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 2,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "skeleton",
	sounds = {
		random = "skeleton",
	},
})
qt_mobs:register_spawn("qt:skeleton_carbonized", {"default:dirt_with_grass", "default:dirt", "default:stone", "default:sand", "default:desert_sand"}, 3, -1, 900, 3, 31000)

minetest.register_craftitem(":qt:spawn_skeleton_carbonized", {
	description = "Spawn Carbonized Skeleton",
	inventory_image = "spawn_skeleton_carbonized.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:skeleton_carbonized")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_skeleton_carbonized", {
	description = "Carbonized Skeleton Spawner",
	paramtype = "light",
	tiles = {"carbonized_skeleton_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_skeleton_carbonized"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:skeleton_carbonized" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 8 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:skeleton_carbonized")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:criminal", {
	type = "monster",
	hp_max = 10,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "human.x",
	textures = {"criminal.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "default:copper_ingot",
		chance = 1,
		min = 3,
		max = 6,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 189,
		punch_end = 198,
	},
	allience = "criminal",
	sounds = {
		random = "criminal_laugh",
	},
})
qt_mobs:register_spawn("qt:criminal", {"default:dirt_with_grass", "default:dirt", "default:sand"}, 20, 8, 3000, 3, 31000)

minetest.register_craftitem(":qt:spawn_criminal", {
	description = "Spawn Criminal",
	inventory_image = "spawn_criminal.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:criminal")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_criminal", {
	description = "Criminal Spawner",
	paramtype = "light",
	tiles = {"criminal_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_criminal"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:criminal" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:criminal")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:snowman", {
	type = "animal",
	hp_max = 15,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 2, 0.4},
	textures = {"snowman.png"},
	visual = "mesh",
	mesh = "snowman.x",
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 100,
	drops = {
		{name = "default:snow",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 10,
	lava_damage = 50,
	light_damage = 0,
	animation = {
		speed_normal = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
	},
	view_range = 5,
	sounds = {
		--random = "sheep",
	},
	on_rightclick = nil,
})

qt_mobs:register_spawn("qt:snowman", {"default:snow", "default:snowblock", "default:dirt_with_snow"}, 14, -1, 900, 3, 500)

minetest.register_craftitem(":qt:spawn_snowman", {
	description = "Spawn Snowman",
	inventory_image = "spawn_sheep.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:snowman")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_snowman", {
	description = "Snowman Spawner",
	paramtype = "light",
	tiles = {"snowman_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_snowman"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:snowman" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:snowman")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:snowmonster", {
	type = "monster",
	hp_max = 15,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 2, 0.4},
	visual = "mesh",
	mesh = "snowman.x",
	textures = {"snowmonster.png"},
	visual_size = {x=6, y=6},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 4,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
		{name = "default:snow",
		chance = 1,
		min = 1,
		max = 4,},
	},
	armor = 90,
	drawtype = "front",
	water_damage = 10,
	lava_damage = 50,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "shoot",
	arrow = "qt:snowball",
	shoot_interval = 2.5,
	sounds = {
		--attack = "",
	},
	animation = {
		speed_normal = 0,
		stand_start = 0,
		stand_end = 0,
		walk_start = 0,
		walk_end = 0,
	},
})

qt_mobs:register_arrow(":qt:snowball", {
	visual = "sprite",
	visual_size = {x=1, y=1},
	textures = {"default_snowball.png"},
	velocity = 5,
	hit_player = function(self, player)
		local s = self.object:getpos()
		local p = player:getpos()
		local vec = {x=s.x-p.x, y=s.y-p.y, z=s.z-p.z}
		player:punch(self.object, 1.0,  {
			full_punch_interval=1.0,
			damage_groups = {fleshy=1},
		}, vec)
	end,
	hit_node = function(self, pos, node)
	end
})

qt_mobs:register_spawn("qt:snowmonster", {"default:snow", "default:snowblock", "default:dirt_with_snow"}, 7, -1, 900, 3, 500)

minetest.register_craftitem(":qt:spawn_snowmonster", {
	description = "Spawn Snowmonster",
	inventory_image = "spawn_sheep.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:snowmonster")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_snowmonster", {
	description = "Snowmonster Spawner",
	paramtype = "light",
	tiles = {"snowmonster_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_snowmonster"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:snowmonster" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:snowmonster")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:villager", {
	type = "animal",
	hp_max = 20,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "human.x",
	textures = {"villager.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 1,
	drops = {
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	animation = {
		speed_normal = 15,
		speed_run = 20,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 187,
		run_start = 168,
		run_end = 188,
		punch_start = 189,
		punch_end = 198,
	},
	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "default:cobble" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("default:stonebrick"))
		end
		if item:get_name() == "default:stone" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("default:coal_lump"))
		end
		if item:get_name() == "default:desert_stone" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("default:iron_lump"))
		end
		if item:get_name() == "default:steel_ingot" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("qt:chest_viliger1"))
		end
		if item:get_name() == "qt:lilimite_dust" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("qt:plasma_charge"))
		end
		if item:get_name() == "default:gold_ingot" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("default:nyancat"))
		end
		if item:get_name() == "default:copper_ingot" then
			item:take_item()
			clicker:set_wielded_item(item)
			clicker:get_inventory():add_item("main", ItemStack("default:nyancat_rainbow"))
		end
	end,
})

qt_mobs:register_spawn("qt:villager", {"qt:brilliance_dirt_with_grass", "qt:brilliance_dirt", "qt:brilliance_sand"}, 20, 8, 6000, 3, 31000)

minetest.register_craftitem(":qt:spawn_villager", {
	description = "Spawn Villager",
	inventory_image = "spawn_villager.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:villager")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_villager", {
	description = "Villager Spawner",
	paramtype = "light",
	tiles = {"villager_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

minetest.register_abm({
	nodenames = {"qt:spawner_villager"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:villager" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:villager")
			end
		end
	end
})

qt_mobs:register_mob(":qt:sheep", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"sheep_normal.png"},
	visual = "mesh",
	mesh = "sheep.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "qt:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		stand_start = 0,
		stand_end = 80,
		walk_start = 81,
		walk_end = 100,
	},
	follow = "farming:wheat",
	view_range = 5,
	sounds = {
		random = "sheep",
	},

	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "farming:wheat" then
			if not self.tamed then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.tamed = true
			elseif self.naked then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.food = (self.food or 0) + 1
				if self.food >= 8 then
					self.food = 0
					self.naked = false
					self.object:set_properties({
						textures = {"sheep_normal.png"},
						mesh = "sheep.x",
					})
				end
			end
			return
		end
		if clicker:get_inventory() and not self.naked then
			self.naked = true
			if minetest.registered_items["wool:white"] then
				clicker:get_inventory():add_item("main", ItemStack("wool:white "..math.random(1,3)))
			end
			self.object:set_properties({
				textures = {"sheep_normal_shaved.png"},
				mesh = "sheep_shaved.x",
			})
		end
	end,
})
qt_mobs:register_spawn("qt:sheep", {"default:dirt_with_grass"}, 20, 8, 5000, 1, 31000)

minetest.register_craftitem(":qt:spawn_sheep", {
	description = "Spawn Sheep",
	inventory_image = "spawn_sheep.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:sheep")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_sheep", {
	description = "Sheep Spawner",
	paramtype = "light",
	tiles = {"sheep_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})


minetest.register_abm({
	nodenames = {"qt:spawner_sheep"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:sheep" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:sheep")
			end
		end
	end
})


qt_mobs:register_mob(":qt:sheep_magic", {
	type = "animal",
	hp_max = 5,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	textures = {"sheep_magic.png"},
	visual = "mesh",
	mesh = "sheep.x",
	makes_footstep_sound = true,
	walk_velocity = 1,
	armor = 200,
	drops = {
		{name = "qt:meat_raw",
		chance = 1,
		min = 4,
		max = 6,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	drawtype = "front",
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	animation = {
		speed_normal = 15,
		stand_start = 0,
		stand_end = 80,
		walk_start = 81,
		walk_end = 100,
	},
	follow = "qt_magic:magic_dust",
	view_range = 5,
	sounds = {
		random = "sheep",
	},

	on_rightclick = function(self, clicker)
		local item = clicker:get_wielded_item()
		if item:get_name() == "qt:brilliance_leaves" then
			if not self.tamed then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.tamed = true
			elseif self.naked then
				if not minetest.setting_getbool("creative_mode") then
					item:take_item()
					clicker:set_wielded_item(item)
				end
				self.food = (self.food or 0) + 1
				if self.food >= 8 then
					self.food = 0
					self.naked = false
					self.object:set_properties({
						textures = {"sheep_magic.png"},
						mesh = "sheep.x",
					})
				end
			end
			return
		end
		if clicker:get_inventory() and not self.naked then
			self.naked = true
			if minetest.registered_items["qt:magic_dust"] then
				clicker:get_inventory():add_item("main", ItemStack("qt:magic_dust "..math.random(1,3)))
			end
			self.object:set_properties({
				textures = {"sheep_magic_shaved.png"},
				mesh = "sheep_shaved.x",
			})
		end
	end,
})
qt_mobs:register_spawn("qt:sheep_magic", {"qt:brilliance_dirt_with_grass", "qt:brilliance_dirt", "qt:brilliance_sand"}, 20, 8, 4000, 3, 31000)
--qt_mobs:register_spawn("qt:sheep_magic", {"default:dirt_with_grass"}, 20, 8, 1200, 1, 31000)

minetest.register_craftitem(":qt:spawn_sheep_magic", {
	description = "Spawn Magic Sheep",
	inventory_image = "spawn_sheep_magic.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:sheep_magic")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_sheep_magic", {
	description = "Magic Sheep Spawner",
	paramtype = "light",
	tiles = {"sheep_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

minetest.register_abm({
	nodenames = {"qt:spawner_sheep_magic"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:sheep_magic" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < 8 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:sheep_magic")
			end
		end
	end
})

qt_mobs:register_mob(":qt:boss_living_sand", {
	type = "monster",
	hp_max = 75,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	visual = "mesh",
	mesh = "basic_golem.x",
	textures = {"living_sand.png"},
	visual_size = {x=3, y=2.6},
	makes_footstep_sound = true,
	view_range = 15,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 3,
	drops = {
		{name = "default:sand",
		chance = 1,
		min = 1,
		max = 5,},
		{name = "default:mese_crystal",
		chance = 1,
		min = 4,
		max = 5,},
		{name = "default:diamond",
		chance = 3,
		min = 2,
		max = 3,},
		{name = "qt:gem_sky_blue",
		chance = 3,
		min = 2,
		max = 3,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 95,
	drawtype = "front",
	water_damage = 5,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 14,
		walk_start = 15,
		walk_end = 38,
		run_start = 40,
		run_end = 63,
		punch_start = 40,
		punch_end = 63,
	},
	allience = "living_sand",
	sounds = {
		random = "living_sand",
	},
})

minetest.register_craftitem(":qt:spawn_boss_living_sand", {
	description = "Spawn Living Sand Boss",
	inventory_image = "spawn_skeleton.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:boss_living_sand")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:spawn_boss_living_sand',
	recipe = {
		{'qt:soul', 'default:sand', ''},
		{'default:sand', 'default:sand', 'default:sand'},
		{'', 'default:sand', ''},
	}
})

minetest.register_node(":qt:spawner_boss_living_sand", {
	description = "Living Sand Spawner",
	paramtype = "light",
	tiles = {"living_sand_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_living_sand"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_living_sand" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:boss_living_sand")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:boss_avenging_ent", {
	type = "monster",
	hp_max = 100,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	visual = "mesh",
	mesh = "avenging_ent.x",
	textures = {"avenging_ent.png"},
	visual_size = {x=4.5,y=4.5},
	makes_footstep_sound = true,
	view_range = 20,
	walk_velocity = 1,
	run_velocity = 2,
	damage = 7,
	drops = {
		{name = "default:tree",
		chance = 1,
		min = 1,
		max = 5,},
		{name = "default:diamond",
		chance = 1,
		min = 4,
		max = 5,},
		{name = "qt:gem_red",
		chance = 2,
		min = 3,
		max = 4,},
		{name = "qt:gem_green",
		chance = 2,
		min = 3,
		max = 4,},
		{name = "qt:ent_eyeball",
		chance = 2,
		min = 1,
		max = 2,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	light_resistant = true,
	armor = 85,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 10,
	light_damage = 0,
	disable_fall_damage = true,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 24,
		walk_start = 25,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		punch_start = 48,
		punch_end = 62,
	},
	allience = "avenging_ent",
	sounds = {
		random = "ent",
	},
})

minetest.register_craftitem(":qt:spawn_boss_avenging_ent", {
	description = "Spawn Avenging Ent Boss",
	inventory_image = "spawn_avenging_ent.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:boss_avenging_ent")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:spawn_boss_avenging_ent',
	recipe = {
		{'qt:soul', 'default:tree', ''},
		{'default:tree', 'default:tree', 'default:tree'},
		{'', 'default:tree', ''},
	}
})

minetest.register_node(":qt:spawner_boss_avenging_ent", {
	description = "Avenging Ent Spawner",
	paramtype = "light",
	tiles = {"avenging_ent_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_avenging_ent"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_avenging_ent" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:boss_avenging_ent")
			end
		end
	end
 })
end

qt_mobs:register_mob(":qt:boss_zombie_pumpkin", {
	type = "monster",
	hp_max = 100,
	collisionbox = {-0.4, -1, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "basic_zombie.x",
	textures = {"zombie_pumpkin.png"},
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	view_range = 20,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 5,
	drops = {
		{name = "qt:rotten_flesh",
		chance = 1,
		min = 5,
		max = 10,},
		{name = "qt:pumpkin",
		chance = 1,
		min = 1,
		max = 5,},
		{name = "default:obsidian",
		chance = 1,
		min = 3,
		max = 5,},
		{name = "qt:gem_blue",
		chance = 2,
		min = 2,
		max = 3,},
		{name = "default:pick_diamond",
		chance = 5,
		min = 1,
		max = 1,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 125,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 1,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		speed_normal = 15,
		speed_run = 15,
		stand_start = 0,
		stand_end = 79,
		walk_start = 168,
		walk_end = 188,
		run_start = 168,
		run_end = 188,
		punch_start = 0,
		punch_end = 79,
	},
	allience = "zombie",
	sounds = {
		random = "undead_mob_grunt",
	},
})

minetest.register_craftitem(":qt:spawn_boss_zombie_pumpkin", {
	description = "Spawn Pumpkin-Headed Zombie Boss",
	inventory_image = "spawn_zombie.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:boss_zombie_pumpkin")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_node(":qt:spawner_boss_zombie_pumpkin", {
	description = "Pumpkin-Headed Zombie Boss Spawner",
	paramtype = "light",
	tiles = {"zombie_pumpkin_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_zombie_pumpkin"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_zombie_pumpkin" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:boss_zombie_pumpkin")
			end
		end
	end
 })
end

minetest.register_node(":qt:spawnnode_boss_zombie_pumpkin", {
	description = "Pumpkin-Headed Zombie Boss Spawn Node",
	tiles = {"zombie_pumpkin_spawner.png"},
	is_ground_content = false,
	groups = {cracky=1,},
	on_punch = function(pos, node, puncher)
		minetest.remove_node(pos)
		minetest.add_entity({x = pos.x, y = pos.y+1, z = pos.z}, "qt:boss_zombie_pumpkin")
	end,
})

qt_mobs:register_mob(":qt:boss_grim_reaper", {
	type = "monster",
	hp_max = 125,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.9, 0.4},
	visual = "mesh",
	mesh = "grim_reaper.x",
	textures = {"grim_reaper.png"},
	visual_size = {x=5, y=5},
	makes_footstep_sound = true,
	view_range = 25,
	walk_velocity = 1,
	run_velocity = 1.5,
	damage = 12,
	drops = {
		{name = "default:obsidian",
		chance = 2,
		min = 3,
		max = 6,},
		{name = "qt_sky:sky_crystal_dark",
		chance = 1,
		min = 3,
		max = 6,},
		{name = "qt_tools:scythe",
		chance = 1,
		min = 1,
		max = 1,},
		{name = "qt:soul",
		chance = 2,
		min = 1,
		max = 1,},
	},
	armor = 80,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogfight",
	animation = {
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 36,
		run_start = 37,
		run_end = 49,
		punch_start = 37,
		punch_end = 49,
		speed_normal = 15,
		speed_run = 15,
	},
	allience = "grim_reaper",
	sounds = {
		random = "grim_reaper",
	},
})

minetest.register_craftitem(":qt:spawn_boss_grim_reaper", {
	description = "Spawn Grim Reaper Boss",
	inventory_image = "spawn_skeleton_carbonized.png",
	liquids_pointable = false,
	stack_max = 99,
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.type == "node" then
			local p = pointed_thing.above
			p.y = p.y+1
			minetest.env:add_entity(p, "qt:boss_grim_reaper")
			if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:spawn_boss_grim_reaper',
	recipe = {
		{'qt:soul', 'qt:skull', ''},
		{'qt:bone', 'qt:bone', 'qt:bone'},
		{'', 'qt:bone', ''},
	}
})

minetest.register_node(":qt:spawner_boss_grim_reaper", {
	description = "Criminal Spawner",
	paramtype = "light",
	tiles = {"grim_reaper_spawner.png"},
	is_ground_content = true,
	drawtype = "allfaces",
	groups = {cracky=1,level=1},
	drop = "default:steel_ingot",
})

if not minetest.setting_getbool("only_peaceful_mobs") then
 minetest.register_abm({
	nodenames = {"qt:spawner_boss_grim_reaper"},
	interval = 2.0,
	chance = 20,
	action = function(pos, node, active_object_count, active_object_count_wider)
		local player_near = false
		local mobs = 0
		for  _,obj in ipairs(minetest.env:get_objects_inside_radius(pos, 30)) do
			if obj:is_player() then
				player_near = true
			else
				if obj:get_luaentity().name == "qt:boss_grim_reaper" then mobs = mobs + 1 end
			end
		end
		if player_near then
			if mobs < 8 then
				pos.x = pos.x+1
				local p = minetest.find_node_near(pos, 5, {"air"})
				--p.y = p.y+1
				local ll = minetest.env:get_node_light(p)
				local wtime = minetest.env:get_timeofday()
				if not ll then return end
				if ll > 20 then return end
				if ll < -1 then return end
				if minetest.env:get_node(p).name ~= "air" then return end
				p.y = p.y+1
				if minetest.env:get_node(p).name ~= "air" then return end
				if (wtime > 0.2 and wtime < 0.805) and pos.y > 0 then return end
				p.y = p.y-1
				minetest.env:add_entity(p, "qt:boss_grim_reaper")
			end
		end
	end
 })
end
